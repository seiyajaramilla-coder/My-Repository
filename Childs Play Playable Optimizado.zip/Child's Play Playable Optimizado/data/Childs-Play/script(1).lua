
function onBeatHit()
if (curBeat > 128 and curBeat % 2 ==0 and curBeat < 190) then
triggerEvent('Add Camera Zoom','0.02','0.02')
end
if (curBeat > 192 and curBeat % 1 ==0 and curBeat < 206) then
triggerEvent('Add Camera Zoom','0.02','0.02')
end
if (curBeat > 208 and curBeat % 1 ==0 and curBeat < 222) then
triggerEvent('Add Camera Zoom','0.02','0.02')
end
if (curBeat > 224 and curBeat % 1 ==0 and curBeat < 232) then
triggerEvent('Add Camera Zoom','0.02','0.02')
end
if (curBeat > 236 and curBeat % 2 ==0 and curBeat < 248) then
triggerEvent('Add Camera Zoom','0.04','0.02')
end
if (curBeat > 248 and curBeat % 1 ==0 and curBeat < 256) then
triggerEvent('Add Camera Zoom','0.02','0.02')
end
if (curBeat > 256 and curBeat % 4 ==0 and curBeat < 288) then
triggerEvent('Add Camera Zoom','0.01','0.01')
end
if (curBeat > 288 and curBeat % 1 ==0 and curBeat < 304) then
triggerEvent('Add Camera Zoom','0.02','0.02')
end
if (curBeat > 488 and curBeat % 1 ==0 and curBeat < 552) then
triggerEvent('Add Camera Zoom','0.005','0.02')
end
if (curBeat > 554 and curBeat % 1 ==0 and curBeat < 600) then
triggerEvent('Add Camera Zoom','0.005','0.02')
end
if (curBeat > 616 and curBeat % 2 ==0 and curBeat < 680) then
triggerEvent('Add Camera Zoom','0.005','0.02')
end
if (curBeat > 680 and curBeat % 3 ==0 and curBeat < 740) then
triggerEvent('Add Camera Zoom','0.005','0.015')
end
end
