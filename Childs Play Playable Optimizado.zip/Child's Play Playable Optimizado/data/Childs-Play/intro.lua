function onCreatePost()
makeLuaText('name', "THE RAPPER", 1280, 0, 300)-- move to 0
	addLuaText('name')
	setTextFont('name', 'Gumball.ttf')
    setTextAlignment('name','center')
	setTextSize('name', 100)
    setTextBorder('name', 0.0, '000000')
    setProperty('name.alpha',0)
    setTextColor('name','ffffff')
	setObjectCamera('name', 'camOther')
	
	makeLuaText('line', "_", 1260, 0, 320)-- move to 0
	addLuaText('line')
    setTextAlignment('line','center')
	setTextSize('line', 100)
	setProperty('line.scale.x',11.5)
    setTextBorder('line', 0.0, '000000')
    setProperty('line.alpha',0)
    setTextColor('line','ffffff')
	setObjectCamera('line', 'camOther')
	
	makeLuaText('melody', "A MELODY OF JOY", 1280, 0, 410)-- move to 0
	addLuaText('melody')
	setTextFont('melody', 'Gumball.ttf')
    setTextAlignment('melody','center')
	setTextSize('melody', 50)
    setTextBorder('melody', 0.0, '000000')
    setProperty('melody.alpha',0)
    setTextColor('melody','ffffff')
	setObjectCamera('melody', 'camOther')
	
	makeLuaText('by', "BY KEYMO", 1280, 0, 450)-- move to 0
	addLuaText('by')
	setTextFont('by', 'Gumball.ttf')
    setTextAlignment('by','center')
	setTextSize('by', 50)
    setTextBorder('by', 0.0, '000000')
    setProperty('by.alpha',0)
    setTextColor('by','ffffff')
	setObjectCamera('by', 'camOther')
end

function onStepHit()
if curStep == 512 then
doTweenAlpha('name', 'name', 1, 1, 'sineInOut')
doTweenAlpha('line', 'line', 1, 1, 'sineInOut')
end
if curStep == 520 then
doTweenAlpha('melody', 'melody', 1, 1, 'sineInOut')
doTweenAlpha('by', 'by', 1, 1, 'sineInOut')
doTweenY('melodyY', 'melody.scale', 0.8, 7, 'cubeOut')
doTweenY('byY', 'by.scale', 0.8, 7, 'cubeOut')
doTweenX('melodyX', 'melody.scale', 0.8, 7, 'cubeOut')
doTweenX('byX', 'by.scale', 0.8, 7, 'cubeOut')
end 
if curStep == 564 then
doTweenAlpha('name', 'name', 0, 1, 'sineInOut')
doTweenAlpha('line', 'line', 0, 1, 'sineInOut')
doTweenAlpha('melody', 'melody', 0, 1, 'sineInOut')
doTweenAlpha('by', 'by', 0, 1, 'sineInOut')
end
end
