function onCreatePost()
makeLuaText('back', "WANT TO GO BACK..?", 1280, 0, 350)-- move to 0
	addLuaText('back')
	setTextFont('back', 'Gumball.ttf')
    setTextAlignment('back','center')
	setTextSize('back', 60)
    setTextBorder('back', 0.0, '000000')
    setProperty('back.alpha',0)
    setTextColor('back','ffffff')
	setObjectCamera('back', 'camOther')
end

function onStepHit()
if curStep == 453 then
doTweenAlpha("back","back", 1, 3, true);
doTweenY('backY', 'back.scale', 2, 5, 'cubeOut')
doTweenX('backX', 'back.scale', 2, 5, 'cubeOut') 
end
if curStep == 463 then
doTweenColor('backColor','back','ff0000',3,'cubeIn')
end
if curStep == 500 then
doTweenAlpha('back', 'back', 0, 1, 'sineInOut')
end
end