function onCreatePost()
makeAnimatedLuaSprite('noteslua', 'NOTE_assets', 500,250);
    addAnimationByPrefix('noteslua', 'singLEFT', 'purple0000', 24, false);
    addAnimationByPrefix('noteslua', 'singDOWN', 'blue0000', 24, false);
    addAnimationByPrefix('noteslua', 'singUP', 'green0000', 24, false);
    addAnimationByPrefix('noteslua', 'singRIGHT', 'red0000', 24, false);
    setObjectCamera('noteslua', 'camHUD')
    scaleObject('noteslua', 2, 2)
    addLuaSprite('noteslua', true);
    setProperty('noteslua.visible',false)
    end 
   

function goodNoteHit(id, dir, noteType, isSustainNote)
if dir == 0 and curBeat < 64 then
	playAnim('noteslua','singRIGHT',true)
	runTimer('idle back', 0.025)
	setProperty('noteslua.visible',true) 
	end
	if dir == 1 and curBeat < 64 then
	playAnim('noteslua','singDOWN',true)
	runTimer('idle back', 0.025)
	setProperty('noteslua.visible',true) 
	end
	if dir == 2 and curBeat < 64 then
	playAnim('noteslua','singUP',true)
	runTimer('idle back', 0.025)
	setProperty('noteslua.visible',true) 
	end
	if dir == 3 and curBeat < 64 then
	playAnim('noteslua','singRIGHT',true)
	runTimer('idle back', 0.025)
	setProperty('noteslua.visible',true)  
	end
end

function onTimerCompleted(t)
    if t == 'idle back' then
        setProperty('noteslua.visible',false)
    end
end