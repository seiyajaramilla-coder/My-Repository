local screenShakeEnabled = false-- Desactivado por defecto
function onStepHit()
if curStep == 1824 then
    setProperty('healthGain',0.5)
    setProperty('health', 2);  
setProperty("boyfriend.color", getColorFromHex("707090"))
setProperty("dad.color", getColorFromHex("707090"))
        screenShakeEnabled = true -- Activar en el beat 1800
    end
   if curStep == 1953 then
        screenShakeEnabled = false -- Activar en el beat 1800
    end 
end

function onUpdate() 
    if screenShakeEnabled then
    runHaxeCode([[
game.camGame.shake(FlxG.random.float(0.0025, 0.003));
game.camHUD.shake(FlxG.random.float(0.0025, 0.003));
game.camOther.shake(FlxG.random.float(0.0025, 0.003));
]])
        else
        runHaxeCode([[
game.camGame.shake(FlxG.random.float(0, 0), FlxG.random.float(0, 0));
game.camHUD.shake(FlxG.random.float(0, 0), FlxG.random.float(0, 0));
game.camOther.shake(FlxG.random.float(0, 0), FlxG.random.float(0, 0));
]])
    end
end
