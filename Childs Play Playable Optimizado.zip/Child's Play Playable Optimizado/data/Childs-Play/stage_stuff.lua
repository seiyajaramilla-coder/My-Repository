
function onEvent(n,v1, v2)
if n == 'badappleeidk' then
v1 = v1:lower() == 'true'
		v2 = (tonumber(v2) or 4)*stepCrochet/1000*playbackRate
		end
	if n == 'badappleeidk' then -- misc stuff
		if v1 then -- fuck im sorry for spamming please forgive me
			twnexists = true
			doTweenX('camoffsethng', 'camoffsethng', 30, v2, 'cubeInOut')
			for i = 1,2 do doTweenY('coolassbartweenY'..i, 'coolassbar'..i, i==1 and 0 or screenHeight-100, v2, 'cubeInOut') end
			-- doTweenAlpha('vignetteass', 'vignette', 1, v2, 'sineInOut')
			if not downscroll then
			doTweenX('healthBargoesbrrX', 'Opo-G', getProperty('Opo-G.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('healthBargoesbrrY', 'Opo-G', 1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			doTweenX('healthBargoesbrr2X', 'Opo-R', getProperty('Opo-R.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('healthBargoesbrr2Y', 'Opo-R', 1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			doTweenX('healthBargoesbrr3X', 'Opo-line', getProperty('Opo-line.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('healthBargoesbrr3Y', 'Opo-line', 1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			doTweenX('healthBargoesbrr4X', 'healthBarScript', getProperty('healthBarScript.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('healthBargoesbrr4Y', 'healthBarScript', 1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			doTweenX('rainbowgoesbrrX', 'rainbow', getProperty('rainbow.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('raimbowgoesbrrY', 'rainbow', 1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			doTweenX('theGlitch2X', 'theGlitch2', getProperty('theGlitch2.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('theGlitch2Y', 'theGlitch2', 1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			doTweenX('glitch1X', 'glitch1', getProperty('glitch1.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('glitch1Y', 'glitch1', 1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			doTweenX('healthTextX', 'healthText', getProperty('healthText.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('healthTextY', 'healthText', 1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			for i = 1,2 do doTweenY('gogogagagicons'..i, 'iconP'..i, 1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn') end
			else
			doTweenX('healthBargoesbrrX', 'Opo-G', getProperty('Opo-G.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('healthBargoesbrrY', 'Opo-G', -1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			doTweenX('healthBargoesbrr2X', 'Opo-R', getProperty('Opo-R.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('healthBargoesbrr2Y', 'Opo-R', -1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			doTweenX('healthBargoesbrr3X', 'Opo-line', getProperty('Opo-line.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('healthBargoesbrr3Y', 'Opo-line', -1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			doTweenX('healthBargoesbrr4X', 'healthBarScript', getProperty('healthBarScript.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('healthBargoesbrr4Y', 'healthBarScript', -1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			doTweenX('rainbowgoesbrrX', 'rainbow', getProperty('rainbow.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('raimbowgoesbrrY', 'rainbow', -1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			doTweenX('theGlitch2X', 'theGlitch2', getProperty('theGlitch2.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('theGlitch2Y', 'theGlitch2', -1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			doTweenX('glitch1X', 'glitch1', getProperty('glitch1.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('glitch1Y', 'glitch1', -1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			doTweenX('healthTextX', 'healthText', getProperty('healthText.x')+(getRandomBool() and getRandomInt(-100,-70) or getRandomInt(70,100)), v2+getRandomFloat(0,1), 'linear')
			doTweenY('healthTextY', 'healthText', -1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn')
			for i = 1,2 do doTweenY('gogogagagicons'..i, 'iconP'..i, -1100+getRandomInt(-200,200), v2+getRandomFloat(0,1), 'backIn') end
			end
		else
			twnexists = true
			doTweenX('camoffsethng', 'camoffsethng', 15, v2, 'cubeInOut')
			for i = 1,2 do doTweenY('coolassbartweenY'..i, 'coolassbar'..i, i==1 and -100 or screenHeight, v2, 'cubeInOut') end
			-- doTweenAlpha('vignetteass', 'vignette', 1, v2, 'sineInOut')
			if not downscroll then
			doTweenX('healthBargoesbrrX', 'healthBarScript', 400, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('healthBargoesbrrY', 'healthBarScript', 625, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenX('healthBargoesbrr2X', 'Opo-G', 380, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('healthBargoesbrr2Y', 'Opo-G', 465, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenX('healthBargoesbrr3X', 'Opo-R', 380, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('healthBargoesbrr3Y', 'Opo-R', 465, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenX('healthBargoesbrr4X', 'Opo-line', 380, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('healthBargoesbrr4Y', 'Opo-line', 465, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenX('rainbowgoesbrrX', 'rainbow', 537, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('raimbowgoesbrrY', 'rainbow', 510, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenX('theGlitch2X', 'theGlitch2', 550, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('theGlitch2Y', 'theGlitch2', 495, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenX('glitch1X', 'glitch1', 600, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('glitch1Y', 'glitch1', 520, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenX('healthTextX', 'healthText', 380, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('healthTextY', 'healthText', 600, v2+getRandomFloat(0,.5), 'cubeOut')
			for i = 1,2 do doTweenY('gogogagagicons'..i, 'iconP'..i, 569.8, v2+getRandomFloat(0,.5), 'cubeOut') end
			else
			doTweenX('healthBargoesbrrX', 'healthBarScript', 400, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('healthBargoesbrrY', 'healthBarScript', 75, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenX('healthBargoesbrr2X', 'Opo-G', 380, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('healthBargoesbrr2Y', 'Opo-G', -85, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenX('healthBargoesbrr3X', 'Opo-R', 380, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('healthBargoesbrr3Y', 'Opo-R', -85, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenX('healthBargoesbrr4X', 'Opo-line', 380, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('healthBargoesbrr4Y', 'Opo-line', -85, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenX('rainbowgoesbrrX', 'rainbow', 537, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('raimbowgoesbrrY', 'rainbow', -40, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenX('theGlitch2X', 'theGlitch2', 550, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('theGlitch2Y', 'theGlitch2', -53, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenX('glitch1X', 'glitch1', 600, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('glitch1Y', 'glitch1', -38, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenX('healthTextX', 'healthText', 380, v2+getRandomFloat(0,.5), 'cubeOut')
			doTweenY('healthTextY', 'healthText', 55, v2+getRandomFloat(0,.5), 'cubeOut')
			for i = 1,2 do doTweenY('gogogagagicons'..i, 'iconP'..i, 10.8, v2+getRandomFloat(0,.5), 'cubeOut') end
			end
		end
	end
end