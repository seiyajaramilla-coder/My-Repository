function onCreatePost()
makeLuaText('text', "Wh.....Where am I?", 1280, 0, 300)-- move to 0
	addLuaText('text')
	setTextFont('text', 'Gumball.ttf')
    setTextAlignment('text','center')
	setTextSize('text', 75)
    setTextBorder('text', 0.0, '000000')
    setProperty('text.alpha',0)
    setTextColor('text','ffffff')
	setObjectCamera('text', 'camOther')
	
	makeLuaText('text2', "Here I'm questioning my heart", 1280, 0, 300)-- move to 0
	addLuaText('text2')
	setTextFont('text2', 'Gumball.ttf')
    setTextAlignment('text2','center')
	setTextSize('text2', 75)
    setTextBorder('text2', 0.0, '000000')
    setProperty('text2.alpha',0)
    setTextColor('text2','ffffff')
	setObjectCamera('text2', 'camOther')
	
	makeLuaText('text3', "It's all a Child's Cry?", 1280, 0, 300)-- move to 0
	addLuaText('text3')
	setTextFont('text3', 'Gumball.ttf')
    setTextAlignment('text3','center')
	setTextSize('text3', 75)
    setTextBorder('text3', 0.0, '000000')
    setProperty('text3.alpha',0)
    setTextColor('text3','ffffff')
	setObjectCamera('text3', 'camOther')
	
	makeLuaText('text4', "and a Endless Lie?", 1280, 0, 350)-- move to 0
	addLuaText('text4')
	setTextFont('text4', 'Gumball.ttf')
    setTextAlignment('text4','center')
	setTextSize('text4', 75)
    setTextBorder('text4', 0.0, '000000')
    setProperty('text4.alpha',0)
    setTextColor('text4','ffffff')
	setObjectCamera('text4', 'camOther')
	
	makeLuaText('text5', "Remember... Just make sure to smile", 1280, 0, 300)-- move to 0
	addLuaText('text5')
	setTextFont('text5', 'Gumball.ttf')
    setTextAlignment('text5','center')
	setTextSize('text5', 75)
    setTextBorder('text5', 0.0, '000000')
    setProperty('text5.alpha',0)
    setTextColor('text5','ffffff')
	setObjectCamera('text5', 'camOther')
end

function onStepHit()
if curStep == 1034 then
doTweenAlpha('text', 'text', 1, 1, 'sineInOut')
end
if curStep == 1056 then
doTweenAlpha('text', 'text', 0, 1, 'sineInOut')
doTweenAlpha('text2', 'text2', 1, 1, 'sineInOut')
end
if curStep == 1088 then
doTweenAlpha('text2', 'text2', 0, 1, 'sineInOut')
doTweenAlpha('text3', 'text3', 1, 1, 'sineInOut')
end
if curStep == 1094 then
doTweenAlpha('text4', 'text4', 1, 1, 'sineInOut')
end
if curStep == 1120 then
doTweenAlpha('text3', 'text3', 0, 1, 'sineInOut')
doTweenAlpha('text4', 'text4', 0, 1, 'sineInOut')
doTweenAlpha('text5', 'text5', 1, 1, 'sineInOut')
end
if curStep == 1136 then
doTweenColor('text5Color','text5','ff0000',1.5,'cubeIn')
end
if curStep == 1148 then
doTweenAlpha('text5', 'text5', 0, 1, 'sineInOut')
end
end
