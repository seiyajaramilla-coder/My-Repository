function noteMiss()
    resetHealthBar()
    end

function onCreatePost()
runTimer('fix',2)

makeAnimatedLuaSprite('healthBarScript','health bar/healthbarShader',400,625);
scaleObject('healthBarScript',2,2)
for t=1,41 do
addAnimationByPrefix('healthBarScript', 'health'..t, 'healthbar'..t..'_', 12, true);
end
setObjectCamera('healthBarScript', 'camHUD')
setScrollFactor('healthBarScript', 0.9, 0.9)
addLuaSprite('healthBarScript', false)
setProperty('healthBarScript.alpha', 0)

setProperty('healthBarScript.visible',true)
 setProperty('scoreTxt.x', -260)
 if downscroll then
setProperty('healthBarScript.y', 75)
else
setProperty('healthBarScript.y', 625)
end
end

function onCreate()
setProperty('healthBar.visible', false);
setProperty('healthBarBG.visible', false);    
end

function opponentNoteHit()
resetHealthBar()
end

function goodNoteHit()
resetHealthBar()
end

function resetHealthBar()
    frame = (health*20)
    anim = math.ceil(frame)
    objectPlayAnimation('healthBarScript','health'..anim,true)
    end
    
function onUpdatePost(elapsed)
health = getProperty('health')
end

function onTimerCompleted(tag)
if tag == 'fix' then
resetHealthBar()
end
end

function onBeatHit()
end