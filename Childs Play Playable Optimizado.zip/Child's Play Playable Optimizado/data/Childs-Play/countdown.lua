

function onStartCountdown()
   runHaxeCode([[ 
            Conductor.changeBPM(]]..tostring(89.55)..[[);
            game.setOnLuas('curBpm', Conductor.bpm);
            game.setOnLuas('crochet', Conductor.crochet);
            game.setOnLuas('stepCrochet', Conductor.stepCrochet);
        ]]);
end

function onSongStart()
setProperty('cameraSpeed', 1)
runHaxeCode([[ 
            Conductor.changeBPM(]]..tostring(170)..[[);
            game.setOnLuas('curBpm', Conductor.bpm);
            game.setOnLuas('crochet', Conductor.crochet);
            game.setOnLuas('stepCrochet', Conductor.stepCrochet);
        ]]);
defaultBPM = getPropertyFromClass('Conductor','bpm') 
setPropertyFromClass('Conductor','bpm',defaultBPM)
end

function onCreatePost()
setProperty('cameraSpeed', 999)
setProperty('camFollow.x', 1550)
setProperty('camFollow.y', 720)
triggerEvent('Camera Follow Pos','1550','720')
setProperty('introSoundsSuffix', '-amogusinirl')
setPropertyFromClass('Conductor','bpm', 89.55)
setProperty("skipCountdown", true)

makeAnimatedLuaSprite('Numbers', 'Numbers', 485, 225)
setObjectCamera('Numbers', 'other')
addAnimationByPrefix('Numbers', '3', '3', 30, false)
addAnimationByPrefix('Numbers', '2', '2', 30, false)
addAnimationByPrefix('Numbers', '1', '1', 30, false)
addAnimationByPrefix('Numbers', 'Go', 'Go', 30, false)
setProperty('Numbers.alpha',0);

addLuaSprite('Numbers', true);
mustHitSection = true
end

function cameraBump(isFinal)
runHaxeCode([[
FlxG.camera.zoom += 0.1;
game.camHUD.zoom += 0.1;
]])
if isFinal then
cameraFlash(camOther, 'FFFFFF', 0.25, true)
runHaxeCode([[
cameraBumpTween = FlxTween.tween(FlxG.camera, {zoom : game.defaultCamZoom}, 0.4, {ease: FlxEase.quartOut});
cameraHUDBumpTween = FlxTween.tween(game.camHUD, {zoom : 1}, 0.4, {ease: FlxEase.quartOut});
]])
else
runHaxeCode([[
cameraBumpTween = FlxTween.tween(FlxG.camera, {zoom : FlxG.camera.zoom - 0.05}, 0.4, {ease: FlxEase.quartOut});
cameraHUDBumpTween = FlxTween.tween(game.camHUD, {zoom : game.camHUD.zoom - 0.05}, 0.4, {ease: FlxEase.quartOut});
]])
end
end

function onCountdownTick(counter)
   if counter == 0 then
   cameraBump()
      setProperty('Numbers.alpha',1)
      playAnim('Numbers','3',false)
      playSound('3')
      runTimer('intro3remove',0.38)
   end
   
   if counter == 1 then
   cameraBump()
      setProperty('Numbers.alpha',1)
      playAnim('Numbers','2',false)
      playSound('2')
      runTimer('intro2remove',0.37)
   end
   
   if counter == 2 then
   cameraBump()
      setProperty('Numbers.alpha',1)
      playAnim('Numbers','1',false)
      playSound('1')
      runTimer('intro1remove',0.51)
   end
   
   if counter == 3 then
   cameraBump(true)
      setProperty('Numbers.alpha',1)
      playAnim('Numbers','Go',false)
      playSound('go')
      runTimer('remove',0.45)
   end
end

function onTimerCompleted(tag)
if tag=='intro3remove' then
setProperty('Numbers.alpha',0);
end

if tag=='intro2remove' then
setProperty('Numbers.alpha',0);
end

if tag=='intro1remove' then
setProperty('Numbers.alpha',0);
end

if tag=='remove' then
removeLuaSprite('Numbers',true)
end
end

function onUpdate(elapsed)
if getProperty('Numbers.animation.curAnim.name') == '3' then
    setProperty('Numbers.offset.x',87)
    setProperty('Numbers.offset.y',51)
end
if getProperty('Numbers.animation.curAnim.name') == '2' then
    setProperty('Numbers.offset.x',0)
    setProperty('Numbers.offset.y',0)
end
if getProperty('Numbers.animation.curAnim.name') == '1' then
    setProperty('Numbers.offset.x',7)
    setProperty('Numbers.offset.y',10)
end
if getProperty('Numbers.animation.curAnim.name') == 'Go' then
    setProperty('Numbers.offset.x',172)
    setProperty('Numbers.offset.y',71)
end
end