function onCreatePost()
setTextFont('scoreTxt', 'Gumball.ttf')  
setTextFont('timeTxt', 'Gumball.ttf')
setTextFont('botplayTxt', 'Gumball.ttf')
end