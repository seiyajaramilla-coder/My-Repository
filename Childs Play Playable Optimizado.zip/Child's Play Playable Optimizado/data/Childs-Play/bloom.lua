local shaderName = "bloom1"
local shaderName2 = "NewGlitch2"
randomxd = math.random(10,20)

function onCreatePost()
initLuaShader("bnw")
makeLuaSprite("black and white")
		makeGraphic("black and white", screenWidth, screenHeight)

		setSpriteShader("black and white", "bnw")
    end

function onSongStart()
runHaxeCode([[
            var bnw = game.createRuntimeShader('bnw');
            
            game.camGame.setFilters([new ShaderFilter(bnw),new ShaderFilter(game.getLuaObject("bloom").shader)]);
            game.getLuaObject('black and white').shader = bnw;
            //FlxG.game.setFilters([]);
        ]]
    )
    end

function onStepHit()

	randomxd = math.random(2,5)/math.random(1,3)
		
	if curStep == 128 then
		shaderCoordFix() -- initialize a fix for textureCoord when resizing game window

		makeLuaSprite("bloom1")
		makeGraphic("bloom1", screenWidth, screenHeight)

		setSpriteShader("shaderImage", "bloom1")


		runHaxeCode([[
			var shaderName = "]] .. shaderName .. [[";
			
			game.initLuaShader(shaderName);
			
			var shader1 = game.createRuntimeShader(shaderName);
			game.camGame.setFilters([new ShaderFilter(shader1),new ShaderFilter(game.getLuaObject("bloom").shader)]);
			game.getLuaObject("bloom1").shader = shader1; // setting it into temporary sprite so luas can set its shader uniforms/properties
			return;
		]])
	end
	if curStep == 1656 then
		shaderCoordFix() -- initialize a fix for textureCoord when resizing game window

		makeLuaSprite("NewGlitch2")
		makeGraphic("NewGlitch2", screenWidth, screenHeight)

		setSpriteShader("shaderImage2", "NewGlitch2")


		runHaxeCode([[
			var shaderName = "]] .. shaderName .. [[";
			var shaderName2 = "]] .. shaderName2 .. [[";
			
			game.initLuaShader(shaderName);
			game.initLuaShader(shaderName2);
			
			var shader0 = game.createRuntimeShader(shaderName2);
            var shader1 = game.createRuntimeShader(shaderName);
			game.camGame.setFilters([new ShaderFilter(shader1),new ShaderFilter(shader0),new ShaderFilter(game.getLuaObject("bloom").shader)]);
			game.getLuaObject("NewGlitch2").shader = shader0; // setting it into temporary sprite so luas can set its shader uniforms/properties
			game.getLuaObject("bloom1").shader = shader1; // setting it into temporary sprite so luas can set its shader uniforms/properties
			return;
		]])
		
	end
	if curStep == 1659 then
		setShaderFloat('NewGlitch2', 'negativity', 1)
	end
	if curStep == 1670 then

		removeSpriteShader('NewGlitch2')
		setProperty('camGame.y', 0)
		runHaxeCode([[
			trace(ShaderFilter);
			var chromToggle = game.createRuntimeShader('ChromaticAbberationHUD');
            var shaderVcr = game.createRuntimeShader('glitchChromatic');
            var shaderblur = game.createRuntimeShader('gaussian_blur');
            var shader1 = game.createRuntimeShader('bloom1');
            
			game.camGame.setFilters([new ShaderFilter(shaderVcr),new ShaderFilter(chromToggle),new ShaderFilter(shader1),new ShaderFilter(shaderblur),new ShaderFilter(game.getLuaObject("bloom").shader)]);
			game.camHUD.setFilters([new ShaderFilter(shaderVcr),new ShaderFilter(chromToggle),new ShaderFilter(shaderblur)]);
			game.getLuaObject('chromToggle').shader = chromToggle;
            game.getLuaObject("temporaryShader1").shader = shaderVcr;
            game.getLuaObject("blur").shader = shaderblur; // setting it into temporary sprite so luas can set its shader uniforms/properties
            game.getLuaObject("bloom1").shader = shader1; // setting it into temporary sprite so luas can set its shader uniforms/properties
			
			return;
		]])
		
		setProperty('camGame.y', 0)
	end
	
	setShaderFloat("NewGlitch2", "binaryIntensity", randomxd-2)
end

function onUpdate(elapsed)
    setShaderFloat("shaderImage", "iTime", os.clock())
    setShaderFloat("shaderImage2", "iTime", os.clock())
end

function shaderCoordFix()
    runHaxeCode([[
        resetCamCache = function(?spr) {
            if (spr == null || spr.filters == null) return;
            spr.__cacheBitmap = null;
            spr.__cacheBitmapData = null;
        }
        
        fixShaderCoordFix = function(?_) {
            resetCamCache(game.camGame.flashSprite);
            resetCamCache(game.camHUD.flashSprite);
            resetCamCache(game.camOther.flashSprite);
        }
    
        FlxG.signals.gameResized.add(fixShaderCoordFix);
        fixShaderCoordFix();
        return;
    ]])
    
    local temp = onDestroy
    function onDestroy()
        runHaxeCode([[
            FlxG.signals.gameResized.remove(fixShaderCoordFix);
            return;
        ]])
        if (temp) then temp() end
    end
end

function onCreate()
	if not shadersEnabled then
		close()
	end
end