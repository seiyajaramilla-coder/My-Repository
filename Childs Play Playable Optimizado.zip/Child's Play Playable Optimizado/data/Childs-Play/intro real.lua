function onCreatePost()
makeLuaText('real name', "", 1280, 0, 300)-- move to 0
	addLuaText('real name')
	setTextFont('real name', 'Gumball.ttf')
    setTextAlignment('real name','center')
	setTextSize('real name', 105)
    setTextBorder('real name', 0.0, '000000')
    setProperty('real name.alpha',0)
    setTextColor('real name','ffffff')
    setProperty('real name.scale.y',0.2)
	setProperty('real name.scale.x',0.2)
	setObjectCamera('real name', 'camOther')
	
	makeLuaText('real line', "_", 1260, 0, 320)-- move to 0
	addLuaText('real line')
    setTextAlignment('real line','center')
	setTextSize('real line', 100)
	setProperty('real line.scale.y',0.2)
	setProperty('real line.scale.x',3.5)
    setTextBorder('real line', 0.0, '000000')
    setProperty('real line.alpha',0)
    setTextColor('real line','ffffff')
	setObjectCamera('real line', 'camOther')
	
	makeLuaText('real melody', "A SYMPHONY OF SORROW", 1280, 0, 420)-- move to 0
	addLuaText('real melody')
	setTextFont('real melody', 'Gumball.ttf')
    setTextAlignment('real melody','center')
	setTextSize('real melody', 45)
    setTextBorder('real melody', 0.0, '000000')
    setProperty('real melody.alpha',0)
    setTextColor('real melody','ffffff')
	setObjectCamera('real melody', 'camOther')
	
	makeLuaText('wake up', "WAKE UP", 1280, 0, 310)-- move to 0
	addLuaText('wake up')
	setTextFont('wake up', 'Gumball.ttf')
    setTextAlignment('wake up','center')
	setTextSize('wake up', 105)
    setTextBorder('wake up', 0.0, '000000')
    setProperty('wake up.alpha',0)
    setTextColor('wake up','ff0000')
	setObjectCamera('wake up', 'camOther')
	
end

local fakeSongNames = {"The Rapper", "The Joy", "The Rewind", "A New Start", "The Darkness", "Your Mom", "Mamma Mia"}
local curFakeName = 1;
function onTimerCompleted(tag, loops, loopsLeft)
	if tag == "textChange" then
		curFakeName = curFakeName + 1;
		if curFakeName > #fakeSongNames then curFakeName = 1; end
		setProperty("real name.text", fakeSongNames[curFakeName])
	end
end

function onStepHit()
if curStep == 1826 then
setProperty('wake up.alpha',1)
doTweenAlpha('wake up', 'wake up', 0, 2.5, 'sineInOut')
doTweenY('wake upY', 'wake up.scale', 1.2, 2.5, 'cubeOut')
doTweenX('wake upX', 'wake up.scale', 1.2, 2.5, 'cubeOut')
doTweenY('real nameY', 'real name.scale', 1, 20, 'cubeOut')
doTweenX('real nameX', 'real name.scale', 1, 20, 'cubeOut')
doTweenY('real lineY', 'real line.scale', 1, 20, 'cubeOut')
doTweenX('real lineX', 'real line.scale', 11.5, 20, 'cubeOut') 
doTweenAlpha('real name', 'real name', 1, 8, 'sineInOut')
doTweenAlpha('real line', 'real line', 1, 8, 'sineInOut')
runTimer("textChange", 0.036, 100000)
end
if curStep == 1956 then
cancelTimer("textChange")
setProperty("real name.text", "Child's Play")
doTweenAlpha('real melody', 'real melody', 1, 1, 'sineInOut')
setProperty('real name.scale.y',1)
	setProperty('real name.scale.x',1)
	setProperty('real line.scale.y',1)
	setProperty('real line.scale.x',11.5)
	doTweenY('real melodyY', 'real melody.scale', 0.9, 7, 'cubeOut')
doTweenX('real melodyX', 'real melody.scale', 0.9, 7, 'cubeOut')
doTweenY('real lineY', 'real line.scale', 0.9, 7, 'cubeOut')
doTweenX('real lineX', 'real line.scale', 10.5, 7, 'cubeOut')
doTweenY('real nameY', 'real name.scale', 0.9, 7, 'cubeOut')
doTweenX('real nameX', 'real name.scale', 0.9, 7, 'cubeOut')
end
if curStep == 2004 then
doTweenAlpha('real name', 'real name', 0, 1, 'sineInOut')
doTweenAlpha('real line', 'real line', 0, 1, 'sineInOut')
doTweenAlpha('real melody', 'real melody', 0, 1, 'sineInOut')
end
end
