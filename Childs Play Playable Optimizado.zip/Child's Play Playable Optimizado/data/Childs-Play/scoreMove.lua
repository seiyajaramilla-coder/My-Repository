
function onSongStart()
scoreGF = false
onHUDUpdate()
end

function onCreatePost()
onHUDUpdate()
  initLuaShader('GreenReplacementShader')
  setSpriteShader('healthBarScript','GreenReplacementShader')
end


function onUpdate(elapsed)
scoreGF = false 
onHUDUpdate()
end


function goodNoteHit(id,data,type,sus)
if type =='GF Sing' and not sus then
scoreGF = true 
onHUDUpdate()
elseif not sus then
onHUDUpdate()
scoreGF = false
end
    end
    
                function onHUDUpdate()
              if scoreGF then
 --setProperty('healthBarScript2.visible',true)
 --setProperty('healthBarScript.visible',false)
  color = getIconColor('gf')
  setShaderFloat('healthBarScript','arrayR',getProperty("gf.healthColorArray[0]"))
  setShaderFloat('healthBarScript','arrayG',getProperty("gf.healthColorArray[1]"))
  setShaderFloat('healthBarScript','arrayB',getProperty("gf.healthColorArray[2]"))
elseif not scoreGF then
  --setProperty('healthBarScript.visible',true)
  --setProperty('healthBarScript2.visible',false)
  color = getIconColor('boyfriend')
  setShaderFloat('healthBarScript','arrayR',getProperty("boyfriend.healthColorArray[0]"))
  setShaderFloat('healthBarScript','arrayG',getProperty("boyfriend.healthColorArray[1]"))
  setShaderFloat('healthBarScript','arrayB',getProperty("boyfriend.healthColorArray[2]"))
end
end


function getIconColor(chr)
	local chr = chr or "dad"
	return getColorFromHex(rgbToHex(getProperty(chr .. ".healthColorArray")))
	end
	
	function rgbToHex(array)
  
  return string.format('%.2x%.2x%.2x', array[1], array[2], array[3])
end