
#pragma header

#define iResolution vec3(openfl_TextureSize, 0.)
#define iChannel0 bitmap



void mainImage(out vec4 color, vec2 coord)
{
    vec3 ps = vec3(vec2(1.0) / iResolution.xy, 0.0);
    vec2 uv = coord * ps.xy;
    
    color = GaussianBlur1D(
        iChannel0,
        uv,
        ps.zy * BlurScale,
        BlurSigma,
        BlurSamples);
}

void main() {
	mainImage(gl_FragColor, openfl_TextureCoordv*openfl_TextureSize);
}