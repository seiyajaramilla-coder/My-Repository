#pragma header
uniform float distort;
uniform float iTime;
#define iChannel0 bitmap
#define texture flixel_texture2D
#define fragColor gl_FragColor
#define mainImage main

void mainImage()
{
    vec2 fragCoord = openfl_TextureCoordv * openfl_TextureSize;
    vec2 iResolution = openfl_TextureSize;
    vec2 uv = fragCoord.xy / iResolution.xy;
    float Pi = 6.28318530718;
    
    float Directions1 = 8.0;
    float Quality1 = 2.0;
    float Size1 = distort * 0.75;
    
    vec2 Radius = Size1 / iResolution.xy;
    vec4 Color = texture(iChannel0, uv);
    
    float totalWeight = 1.0;
    for (float d = 0.0; d < Pi; d += Pi / Directions1)
    {
        for (float i = 1.0 / Quality1; i <= 1.0; i += 1.0 / Quality1)
        {
            vec4 sampleColor = texture(iChannel0, uv + vec2(cos(d), sin(d)) * Radius * i);
            Color += sampleColor;
            totalWeight += 1.0;
        }
    }
    
    Color /= totalWeight;
    gl_FragColor = Color;
}