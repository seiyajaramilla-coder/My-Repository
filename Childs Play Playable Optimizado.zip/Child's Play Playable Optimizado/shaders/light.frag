#pragma header

const float amount = 1.0;

uniform float dim;
float Directions = 0.0;
float Quality = 0.0;
float Size = 0.0; 

#define Pi 6.28318530718 // Pi*2

void main() { 
    vec2 Radius = Size / openfl_TextureSize.xy;
    vec2 uv = openfl_TextureCoordv.xy;
    
    vec4 Color = texture2D(bitmap, uv);
    
    for(float d = 0.0; d < Pi; d += Pi / Directions) {
        for(float i = 1.0 / Quality; i <= 1.0; i += 1.0 / Quality) {
            float ex = (cos(d) * Size * i) / openfl_TextureSize.x;
            float why = (sin(d) *Size * i) / openfl_TextureSize.y;
            Color += texture2D(bitmap, uv + vec2(ex, why));
        }
    }
    
    Color /= (dim * Quality) * Directions - 15.0;
    vec4 bloom = (texture2D(bitmap, uv) / dim) + Color;
    
    gl_FragColor = bloom;
}

