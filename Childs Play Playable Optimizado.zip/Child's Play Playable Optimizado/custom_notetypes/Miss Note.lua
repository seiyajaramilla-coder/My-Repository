local luaNote = "Miss Note"
glitch = false
function onCreate()
	--Iterate over all notes
	for i = 0, getProperty('unspawnNotes.length')-1 do
		--Check if the note is an Instakill Note
		if getPropertyFromGroup('unspawnNotes', i, 'noteType') == "Miss Note" then
			--setPropertyFromGroup('unspawnNotes', i, 'texture', 'NOTE_assets'); --Change texture
			--setPropertyFromGroup('unspawnNotes', i, 'hitCausesMiss', true);

			setPropertyFromGroup('unspawnNotes', i, 'ignoreNote', true); --Miss has no penalties
		end
	end
	--debugPrint('Script started!')
end

function onStepHit()
distortIntensity = getRandomFloat(4, 6);
if curStep == 826 then
setProperty("corruptionText.text", "[WRONG]")
end
if curStep == 934 then
setProperty("corruptionText.text", "[TRY HARDER]")
end 
if curStep == 1824 then
glitch = true
setProperty("corruptionText.visible", false)
end
end

function onCreatePost()
makeLuaText("corruptionText", "[FOCUS]", screenWidth, 0, 300)
	setTextFont("corruptionText", "menuTHEME.ttf")
	setTextBorder("corruptionText", 0, "000000")
	setScrollFactor("corruptionText")
	addLuaText("corruptionText")
	setTextSize("corruptionText", 100)
	setTextColor('corruptionText','FF0000')
	setProperty("corruptionText.alpha", 0)
	end
	
	function onUpdatePost(elapsed)
	if glitch == false then
	setProperty('corruptionText.alpha',0)
	end
	if glitch == true then
if math.random(1,4) == 1 then
setProperty('corruptionText.alpha',1)
else
setProperty('corruptionText.alpha',0)
end
end
end

local anims = {"LEFT", "DOWN", "UP", "RIGHT"}
function onUpdate()
	for i = 0, getProperty('notes.length')-1 do
		setPropertyFromGroup('notes', i, 'earlyHitMult', 0.5)
		setPropertyFromGroup('notes', i, 'lateHitMult', 0.5)
		if getPropertyFromGroup('notes', i, 'noteType') == "Miss Note" then
			if getPropertyFromGroup('notes', i, 'wasGoodHit') then
			glitch = true
			setProperty('healthBarScript.alpha', 0.5)
			setProperty('glitch1.alpha', 0.5)
initLuaShader("distort")
initLuaShader("NewGlitch2N")
setShaderFloat("dad", "binaryIntensity", getRandomFloat(-1, -0.5))
setShaderFloat("dad", "negativity", 1) 
setSpriteShader("dad", "distort")
setSpriteShader("dadPhantom", "distort")
setShaderFloat("dadPhantom", "binaryIntensity", getRandomFloat(-1, -0.5))
setShaderFloat("dadPhantom", "negativity", 1) 
runTimer('remove',0.3)
for e = 0,3 do
        setSpriteShader('opponentStrums.members['..e..']', 'NewGlitch2N') -- Inicialmente sin shader
        setShaderFloat('opponentStrums.members['..e..']', 'binaryIntensity', distortIntensity)
    end        
				playAnim("dad", "sing"..anims[getPropertyFromGroup('notes', i, 'noteData')+1], true)
				setProperty("dad.holdTimer", 0)
				callOnLuas("opponentNoteHit", {i, getPropertyFromGroup('notes', i, 'noteData'), getPropertyFromGroup('notes', i, 'noteType'), getPropertyFromGroup('notes', i, 'isSustainNote')})
				runHaxeCode([[
					var member = game.notes.members[]]..i..[[];
					game.callOnHScript('opponentNoteHit', [member]);
				]])
			end
		end
	end
end

function onTimerCompleted(t)
if t == 'remove' then
glitch = false
setProperty('healthBarScript.alpha', 0)
setProperty('glitch1.alpha', 0)
removeSpriteShader('dad')
removeSpriteShader('dadPhantom')
for i=0,3 do
	removeSpriteShader('opponentStrums.members['..i..']')
end
end
end
