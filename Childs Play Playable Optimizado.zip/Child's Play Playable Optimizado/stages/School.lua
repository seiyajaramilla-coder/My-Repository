local shaderSpr = true
function onCreatePost()
setProperty('showComboNum', false)
setProperty('showRating', false)
makeLuaSprite('iconP1Pos',nil, 670, 0);
	makeLuaSprite('iconP2Pos',nil, 470, 0);
hideUi(true, true, false, 0, 0.01, 'linear')
	setProperty('iconP1.alpha', 0)
	setProperty('iconP2.alpha', 0)

	setProperty('timeTxt.alpha', 0)
	setProperty('timeBar.alpha', 0)
	setProperty('timeBarBG.alpha', 0)
	setProperty('scoreTxt.visible', false)
if not downscroll then
		setProperty('iconP1.y', getProperty('iconP1.y')+50)
		setProperty('iconP2.y', 623.8)
		noteTweenY('4', 4, -150, 0.01)
		noteTweenY('5', 5, -150, 0.01)
		noteTweenY('6', 6, -150, 0.01)
		noteTweenY('7', 7, -150, 0.01)
		noteTweenY('0', 0, -150, 0.01)
		noteTweenY('1', 1, -150, 0.01)
		noteTweenY('2', 2, -150, 0.01)
		noteTweenY('3', 3, -150, 0.01)
	elseif downscroll then
		setProperty('iconP1.y', getProperty('iconP1.y')-35)
		setProperty('iconP2.y', getProperty('iconP2.y')-35)
		noteTweenY('4', 4, 760, 0.01)
		noteTweenY('5', 5, 760, 0.01)
		noteTweenY('6', 6, 760, 0.01)
		noteTweenY('7', 7, 760, 0.01)
		noteTweenY('0', 0, 760, 0.01)
		noteTweenY('1', 1, 760, 0.01)
		noteTweenY('2', 2, 760, 0.01)
		noteTweenY('3', 3, 760, 0.01)
	end
	if shaderSpr then
        if shadersEnabled then
		onCreateOBJ()
        end
    end
    if not shaderSpr then
		onCreateOBJ()
        end
	hideUi(true, true, false, 0, 0.01, 'linear')
	setProperty('iconP1.alpha', 0)
	setProperty('iconP2.alpha', 0)

	setProperty('timeTxt.alpha', 0)
	setProperty('timeBar.alpha', 0)
	setProperty('timeBarBG.alpha', 0)
	setProperty('scoreTxt.visible', false)
    end
    
    function onUpdatePost(elapsed)
    setProperty('ochof.x', getProperty('ocho.x')-20)--X--
setProperty('ochof.y', getProperty('ocho.y') + 40)--Y--
setProperty('ochox.x', getProperty('ocho.x')-10)--X--
setProperty('ochox.y', getProperty('ocho.y') + 10)--Y--
setProperty('iconP1.x', getProperty('iconP1Pos.x'))
setProperty('iconP2.x', getProperty('iconP2Pos.x'))

if middlescroll then
	if getProperty('iconP1.alpha') >= 0.5 then
		setProperty('iconP1.alpha', 0.5)
	end
	
	if getProperty('iconP2.alpha') >= 0.5 then
		setProperty('iconP2.alpha', 0.5)
	end
end
setProperty('timeTxt.alpha', 0)
	setProperty('timeBar.alpha', 0)
	setProperty('timeBarBG.alpha', 0)
setProperty('healthBar.visible', false);
setProperty('healthBarBG.visible', false);
end

function onCreateOBJ()
makeAnimatedLuaSprite('tobiasr', 'school/tobias_think', 121, 394)
    addAnimationByPrefix('tobiasr', 'idle', 'think_', 12, true)
    scaleObject('tobiasr',1.85,1.85)
    addLuaSprite('tobiasr')
    
    makeAnimatedLuaSprite('tobiaspr','school/tobiasp',-117, 344)
        addAnimationByPrefix('tobiaspr','idle','tobias idle0',11,false)
        scaleObject('tobiaspr',1.85,1.85);
        addLuaSprite('tobiaspr')
        setProperty('tobiaspr.alpha', 0)
        
        makeAnimatedLuaSprite('tobiasfr','school/Tobias Happy',133, 374)
        addAnimationByPrefix('tobiasfr','idle','idle-00',12,true)
        scaleObject('tobiasfr',1.175,1.175);
        addLuaSprite('tobiasfr')
        setProperty('tobiasfr.alpha', 0)
        
        makeAnimatedLuaSprite('tobiasxr','school/tobiasx',-117, 344)
        addAnimationByPrefix('tobiasxr','idle','tobias idle0',10,true)
        scaleObject('tobiasxr',1.95,1.95);
        addLuaSprite('tobiasxr')
        setProperty('tobiasxr.alpha', 0)
        
        makeAnimatedLuaSprite("pennyNjukedarkr", "school/Penny-and-juke-dark", 650, 313)
		addAnimationByPrefix("pennyNjukedarkr", "idle", "idle", 12, true)
		scaleObject("pennyNjukedarkr",1.8,1.8, true)
		playAnim("pennyNjukedarkr", "idle")
		addLuaSprite('pennyNjukedarkr', false)
		setProperty('pennyNjukedarkr.alpha', 0)
    
    makeAnimatedLuaSprite('aidajor','school/aidajo',890, 675)
        addAnimationByPrefix('aidajor','idle','aidajo idle',12,true)
        scaleObject('aidajor',0.5,0.5);
        addLuaSprite('aidajor', false)
        
        makeAnimatedLuaSprite('aidajopr','school/idahoNEW',881, 570)
        addAnimationByPrefix('aidajopr','idle','anim_',15,false)
        objectPlayAnimation('aidajopr', 'idle', false)
        scaleObject('aidajopr',1.25,1.25);
        addLuaSprite('aidajopr', false)
        setProperty('aidajopr.alpha', 0)
        
        makeAnimatedLuaSprite('aidajofr','school/aidajof',780, 550)
        addAnimationByPrefix('aidajofr','idle','aidajo idle',14,true)
        scaleObject('aidajofr',1.25,1.25);
        addLuaSprite('aidajofr', false)
        setProperty('aidajofr.alpha', 0)
        
        makeAnimatedLuaSprite('aidajoxr','school/aidajox',550, 550)
        addAnimationByPrefix('aidajoxr','idle','aidajo idle0',13,true)
        scaleObject('aidajoxr',1.25,1.25);
        addLuaSprite('aidajoxr')
        setProperty('aidajoxr.alpha', 0)
        
        makeAnimatedLuaSprite('carmenr','school/Carmen',1600, 475)
        addAnimationByPrefix('carmenr','idle','idle',12,true)
        scaleObject('carmenr',2.6,2.6);
        addLuaSprite('carmenr', false)
        
        makeAnimatedLuaSprite('carmenpr','school/carmenp',1672, 517)
        addAnimationByPrefix('carmenpr','idle','idle',18,false)
        scaleObject('carmenpr',1.625,1.625);
        addLuaSprite('carmenpr', false)
        setProperty('carmenpr.alpha', 0)
        
        makeAnimatedLuaSprite('carmenfr','school/carmenf',1690, 550)
        addAnimationByPrefix('carmenfr','idle','carmen idle',24,true)
        scaleObject('carmenfr',0.8,0.8);
        addLuaSprite('carmenfr', false)
        setProperty('carmenfr.alpha', 0)
        
        makeAnimatedLuaSprite('carmenxr','school/carmenx',1690, 550)
        addAnimationByPrefix('carmenxr','idle','carmen idle',24,true)
        scaleObject('carmenxr',0.8,0.8);
        addLuaSprite('carmenxr', false)
        setProperty('carmenxr.alpha', 0)
    
    setProperty('tobiasr.x', getProperty('tobias.x'))--X--
setProperty('tobiasr.y', getProperty('tobias.y') + 400)--Y--
setProperty('tobiasr.alpha', 0.35)
setProperty('tobiasr.angle', 180)
setProperty('tobiasr.flipX', true)
setObjectOrder('tobiasr', getObjectOrder('tobias'))

setProperty('tobiaspr.x', getProperty('tobiasp.x'))--X--
setProperty('tobiaspr.y', getProperty('tobiasp.y') + 472)--Y--
setProperty('tobiaspr.alpha', 0)
setProperty('tobiaspr.angle', 180)
setProperty('tobiaspr.flipX', true)
setObjectOrder('tobiaspr', getObjectOrder('tobiasp'))

setProperty('tobiasfr.x', getProperty('tobiasf.x'))--X--
setProperty('tobiasfr.y', getProperty('tobiasf.y') + 472)--Y--
setProperty('tobiasfr.alpha', 0)
setProperty('tobiasfr.angle', 180)
setProperty('tobiasfr.flipX', true)
setObjectOrder('tobiasfr', getObjectOrder('tobiasf'))

setProperty('tobiasxr.x', getProperty('tobiasx.x'))--X--
setProperty('tobiasxr.y', getProperty('tobiasx.y') + 472)--Y--
setProperty('tobiasxr.alpha', 0)
setProperty('tobiasxr.angle', 180)
setProperty('tobiasxr.flipX', true)
setObjectOrder('tobiasxr', getObjectOrder('tobiasx'))

setProperty('aidajor.x', getProperty('aidajo.x'))--X--
setProperty('aidajor.y', getProperty('aidajo.y') + 190)--Y--
setProperty('aidajor.alpha', 0.35)
setProperty('aidajor.angle', 180)
setProperty('aidajor.flipX', true)
setObjectOrder('aidajor', getObjectOrder('aidajo'))

setProperty('aidajopr.x', getProperty('aidajop.x'))--X--
setProperty('aidajopr.y', getProperty('aidajop.y') + 260)--Y--
setProperty('aidajopr.alpha', 0)
setProperty('aidajopr.angle', 180)
setProperty('aidajopr.flipX', true)
setObjectOrder('aidajopr', getObjectOrder('aidajop'))

setProperty('aidajofr.x', getProperty('aidajof.x'))--X--
setProperty('aidajofr.y', getProperty('aidajof.y') + 300)--Y--
setProperty('aidajofr.alpha', 0)
setProperty('aidajofr.angle', 180)
setProperty('aidajofr.flipX', true)
setObjectOrder('aidajofr', getObjectOrder('aidajof'))

setProperty('aidajoxr.x', getProperty('aidajox.x'))--X--
setProperty('aidajoxr.y', getProperty('aidajox.y') + 300)--Y--
setProperty('aidajoxr.alpha', 0)
setProperty('aidajoxr.angle', 180)
setProperty('aidajoxr.flipX', true)
setObjectOrder('aidajoxr', getObjectOrder('aidajox'))

setProperty('carmenr.x', getProperty('carmen.x'))--X--
setProperty('carmenr.y', getProperty('carmen.y') + 395)--Y--
setProperty('carmenr.alpha', 0.35)
setProperty('carmenr.angle', 180)
setProperty('carmenr.flipX', true)
setObjectOrder('carmenr', getObjectOrder('carmen'))

setProperty('carmenpr.x', getProperty('carmenp.x'))--X--
setProperty('carmenpr.y', getProperty('carmenp.y') + 350)--Y--
setProperty('carmenpr.alpha', 0)
setProperty('carmenpr.angle', 180)
setProperty('carmenpr.flipX', true)
setObjectOrder('carmenpr', getObjectOrder('carmenp'))

setProperty('carmenfr.x', getProperty('carmenf.x'))--X--
setProperty('carmenfr.y', getProperty('carmenf.y') + 330)--Y--
setProperty('carmenfr.alpha', 0)
setProperty('carmenfr.angle', 180)
setProperty('carmenfr.flipX', true)
setObjectOrder('carmenfr', getObjectOrder('carmenf'))

setProperty('carmenxr.x', getProperty('carmenx.x'))--X--
setProperty('carmenxr.y', getProperty('carmenx.y') + 330)--Y--
setProperty('carmenxr.alpha', 0)
setProperty('carmenxr.angle', 180)
setProperty('carmenxr.flipX', true)
setObjectOrder('carmenxr', getObjectOrder('carmenx'))

setProperty('pennyNjukedarkr.x', getProperty('pennyNjukedark.x'))--X--
setProperty('pennyNjukedarkr.y', getProperty('pennyNjukedark.y') + 470)--Y--
setProperty('pennyNjukedarkr.alpha', 0)
setProperty('pennyNjukedarkr.angle', 180)
setProperty('pennyNjukedarkr.flipX', true)
setObjectOrder('pennyNjukedarkr', getObjectOrder('pennyNjukedark'))
end

    
function onCreate()
    makeLuaSprite('background', 'school/bg', 20, -300)
    scaleObject('background', 1.83,1.83)
    addLuaSprite('background', false)
    
    makeLuaSprite('background2', 'school/bg2', -5, -184)
    scaleObject('background2', 1.32,1.32)
    addLuaSprite('background2', false)
    setProperty('background2.alpha', 0)
    
    makeAnimatedLuaSprite('sinkgoop', 'school/sinkgoop', 595, 520);
   addAnimationByPrefix('sinkgoop','idle','gooey0',24, true);
   setScrollFactor('sinkgoop', 1, 1);
   scaleObject('sinkgoop', 1.7, 1.7);
   addLuaSprite('sinkgoop', false);
   setProperty('sinkgoop.alpha', 0)
   
   makeAnimatedLuaSprite('droplet', 'school/droplet', 900, 215);
   addAnimationByPrefix('droplet','idle','gooey0',24, true);
   scaleObject('droplet', 1.7, 1.7);
   addLuaSprite('droplet', false);
   setProperty('droplet.alpha', 0)
   
   makeAnimatedLuaSprite('droplet2', 'school/droplet2', 300, 755);
   addAnimationByPrefix('droplet2','idle','gooey0',24, true);
   setScrollFactor('droplet2', 1, 1);
   scaleObject('droplet2', 1.7, 1.7);
   addLuaSprite('droplet2', false);
   setProperty('droplet2.alpha', 0)
    
    makeLuaSprite('party', 'school/p1',-40, 50);
addLuaSprite('party', false)
setScrollFactor('party',2.1,2.1)
scaleObject('party',0.69, 0.7)

makeLuaSprite('party4', 'school/p4',-45, 70);
addLuaSprite('party4', false)
setScrollFactor('party4',2.2,2.2)
scaleObject('party4',0.69, 0.7)

makeLuaSprite('party3', 'school/p3',25, 40);
addLuaSprite('party3', false)
setScrollFactor('party3',2.1,2.1)
scaleObject('party3',0.6, 0.6)

makeAnimatedLuaSprite('ocho', 'school/Ocho', 900, 200)
    addAnimationByPrefix('ocho', 'idle', 'idle', 14, false)
    scaleObject('ocho', 0.94, 0.94)
    addLuaSprite('ocho')
    
    makeAnimatedLuaSprite('ochof', 'school/Ochof', 900, 200)
    addAnimationByPrefix('ochof', 'idle', 'idle', 5, false)
    scaleObject('ochof', 0.50, 0.50)
    addLuaSprite('ochof')
    setProperty('ochof.alpha', 0)
    
    makeAnimatedLuaSprite('ochox', 'school/Ochox', 900, 200)
    addAnimationByPrefix('ochox', 'idle', 'idle', 12, true)
    scaleObject('ochox', 0.56, 0.56)
    addLuaSprite('ochox')
    setProperty('ochox.alpha', 0) 
    
    makeAnimatedLuaSprite('carrie', 'school/carry', 400, 250)
    addAnimationByPrefix('carrie', 'idle', 'carry idle', 15, true)
    scaleObject('carrie', 0.675, 0.675)
    addLuaSprite('carrie')
    setProperty('carrie.alpha', 0.9)
    
    makeAnimatedLuaSprite('carriep','school/carryp', -10, -35)
        addAnimationByPrefix('carriep','idle','carry idle0',12,false)
        scaleObject('carriep',1.27,1.27);
        addLuaSprite('carriep')
        setProperty('carriep.alpha', 0)

makeAnimatedLuaSprite('carrief','school/carryf',-10, -35)
        addAnimationByPrefix('carrief','idle','carry idle0',15,true)
        scaleObject('carrief',1.27,1.27);
        addLuaSprite('carrief')
        setProperty('carrief.alpha', 0)
        
        makeAnimatedLuaSprite('carriex','school/carryx',-10, -35)
        addAnimationByPrefix('carriex','idle','carry idle0',15,true)
        scaleObject('carriex',1.27,1.27);
        addLuaSprite('carriex')
        setProperty('carriex.alpha', 0)
        
    makeAnimatedLuaSprite('alan', 'school/Alan', 1400, 175)
    addAnimationByPrefix('alan', 'idle', 'idle', 22, true)
    scaleObject('alan',1.75,1.75)
    addLuaSprite('alan', false)
    doTweenY('alanY', 'alan', 200, 1, 'sineInOut')
    
    makeAnimatedLuaSprite('alanp','school/alanp',1150, 175)
        addAnimationByPrefix('alanp','idle','alan idle',12, false)
        objectPlayAnimation('alanp', 'idle', false)
        scaleObject('alanp',2,2);
        addLuaSprite('alanp', false)
        setProperty('alanp.alpha', 0)
        doTweenY('alanpY', 'alanp', 200, 1, 'sineInOut')

makeAnimatedLuaSprite('alanf','school/alanf',1150, 175)
        addAnimationByPrefix('alanf','idle','alan idle0',12,true)
        scaleObject('alanf',2,2);
        addLuaSprite('alanf', false)
        setProperty('alanf.alpha', 0)
        doTweenY('alanfY', 'alanf', 200, 1, 'sineInOut')
        
        makeAnimatedLuaSprite('alanx','school/alanx',1150, 175)
        addAnimationByPrefix('alanx','idle','alan idle0',12,true)
        scaleObject('alanx',2,2);
        addLuaSprite('alanx', false)
        setProperty('alanx.alpha', 0)
        doTweenY('alanxY', 'alanx', 200, 1, 'sineInOut')
    
    addLuaSprite('pennyNjuker', false)
    addLuaSprite('pennyNjuke', false)
    addLuaSprite('pennyNjuke2', false);
    
    makeAnimatedLuaSprite("pennyNjukedark", "school/Penny-and-juke-dark", 650, 313)
		addAnimationByPrefix("pennyNjukedark", "idle", "idle", 12, true)
		scaleObject("pennyNjukedark",1.8,1.8, true)
		playAnim("pennyNjukedark", "idle")
		addLuaSprite('pennyNjukedark', false)
		setProperty('pennyNjukedark.alpha', 0)
    
    makeAnimatedLuaSprite('aidajo','school/aidajo',890, 675)
        addAnimationByPrefix('aidajo','idle','aidajo idle',12,true)
        scaleObject('aidajo',0.5,0.5);
        addLuaSprite('aidajo', false)
        
        makeAnimatedLuaSprite('aidajop','school/idahoNEW',881, 570)
        addAnimationByPrefix('aidajop','idle','anim_',15,false)
        objectPlayAnimation('aidajop', 'idle', false)
        scaleObject('aidajop',1.25,1.25);
        addLuaSprite('aidajop', false)
        setProperty('aidajop.alpha', 0)
        
        makeAnimatedLuaSprite('aidajof','school/aidajof',780, 550)
        addAnimationByPrefix('aidajof','idle','aidajo idle',14,true)
        scaleObject('aidajof',1.25,1.25);
        addLuaSprite('aidajof', false)
        setProperty('aidajof.alpha', 0)
        
        makeAnimatedLuaSprite('aidajox','school/aidajox',550, 550)
        addAnimationByPrefix('aidajox','idle','aidajo idle0',13,true)
        scaleObject('aidajox',1.25,1.25);
        addLuaSprite('aidajox')
        setProperty('aidajox.alpha', 0)
        
        makeAnimatedLuaSprite('carmen','school/Carmen',1600, 475)
        addAnimationByPrefix('carmen','idle','idle',12,true)
        scaleObject('carmen',1.3,1.3);
        addLuaSprite('carmen', false)
        
        makeAnimatedLuaSprite('carmenp','school/carmenp',1672, 517)
        addAnimationByPrefix('carmenp','idle','idle',18,false)
        scaleObject('carmenp',1.625,1.625);
        addLuaSprite('carmenp', false)
        setProperty('carmenp.alpha', 0)
        
        makeAnimatedLuaSprite('carmenf','school/carmenf',1690, 550)
        addAnimationByPrefix('carmenf','idle','carmen idle',24,true)
        scaleObject('carmenf',0.8,0.8);
        addLuaSprite('carmenf', false)
        setProperty('carmenf.alpha', 0)
        
        makeAnimatedLuaSprite('carmenx','school/carmenx',1690, 550)
        addAnimationByPrefix('carmenx','idle','carmen idle',24,true)
        scaleObject('carmenx',0.8,0.8);
        addLuaSprite('carmenx', false)
        setProperty('carmenx.alpha', 0)
    
    makeAnimatedLuaSprite('tobias', 'school/tobias_think', 121, 394)
    addAnimationByPrefix('tobias', 'idle', 'think_', 12, true)
    scaleObject('tobias',1.85,1.85)
    addLuaSprite('tobias')
    
    makeAnimatedLuaSprite('tobiasp','school/tobiasp',-117, 344)
        addAnimationByPrefix('tobiasp','idle','tobias idle0',10,false)
        scaleObject('tobiasp',1.95,1.95);
        addLuaSprite('tobiasp')
        setProperty('tobiasp.alpha', 0)
        
        makeAnimatedLuaSprite('tobiasf','school/Tobias Happy',133, 374)
        addAnimationByPrefix('tobiasf','idle','idle-00',12,true)
        scaleObject('tobiasf',1.175,1.175);
        addLuaSprite('tobiasf')
        setProperty('tobiasf.alpha', 0)
        
        makeAnimatedLuaSprite('tobiasx','school/tobiasx',-117, 344)
        addAnimationByPrefix('tobiasx','idle','tobias idle0',10,true)
        scaleObject('tobiasx',1.95,1.95);
        addLuaSprite('tobiasx')
        setProperty('tobiasx.alpha', 0)
    
    makeAnimatedLuaSprite('masami', 'school/masami', 995, 150)
    addAnimationByPrefix('masami', 'idle', 'idle0', 12, true)
    addAnimationByPrefix('masami', 'transition', 'Happyanimation', 12, false)
    addAnimationByPrefix('masami', 'idle happy', 'idlehappy', 12, true)
    addAnimationByPrefix('masami', 'corrupted', 'Corruptedidle', 12, true)
    scaleObject('masami', 1.4, 1.4)
    addLuaSprite('masami')
    
    makeLuaSprite('wall', 'school/pared',-130, -160);
addLuaSprite('wall', true)
setScrollFactor('wall',1.2, 1)
scaleObject('wall',2.2,2.2)

makeLuaSprite('wall2', 'school/pared2',-130, -260);
addLuaSprite('wall2', true)
setScrollFactor('wall2',1.2, 1)
scaleObject('wall2',2.2,2.2)
setProperty('wall2.alpha', 0)

makeAnimatedLuaSprite('topgoop', 'school/topgoop', -200, -115);
   addAnimationByPrefix('topgoop','idle','gooey0',24, true);
   setScrollFactor('topgoop',1.2, 1.2)
   scaleObject('topgoop',3,3);
   addLuaSprite('topgoop', true);
   setProperty('topgoop.alpha', 0)
   
   makeAnimatedLuaSprite('secondtopgoop', 'school/secondtopgoop', 1410, -5);
   addAnimationByPrefix('secondtopgoop','idle','gooey0',24, true);
   setScrollFactor('secondtopgoop',1.05, 1.05)
   scaleObject('secondtopgoop', 1.5, 1.5);
   addLuaSprite('secondtopgoop', true);
   setProperty('secondtopgoop.alpha', 0)

makeAnimatedLuaSprite('bobert', 'school/bobe', 0, 825)
addAnimationByPrefix('bobert','Dance','bobe idle',24,true)
    objectPlayAnimation('bobert','Dance',false)
    addLuaSprite('bobert', true)
    scaleObject('bobert', 1.4, 1.4)
    setProperty('bobert.alpha', 1)
    setScrollFactor('bobert', 1.1, 1.1)
    
    makeLuaSprite('bobertx', 'school/bobex', -530, 385)
    scaleObject('bobertx', 1.2,1.2)
    addLuaSprite('bobertx', true)
    setScrollFactor('bobertx', 1.1, 1.1)
    setProperty('bobertx.alpha', 0)
    
    makeAnimatedLuaSprite('sal', 'school/sal', 1900, 600)
addAnimationByPrefix('sal','Dance','sal idle',12,true)
    objectPlayAnimation('sal','Dance',false)
    addLuaSprite('sal', true)
    scaleObject('sal', 2.4,2.4)
    setProperty('sal.alpha', 1)
    setScrollFactor('sal', 1.1, 1.1)
    
    makeLuaSprite('salx', 'school/salx', 1510, 619)
    scaleObject('salx', 0.6,0.6)
    addLuaSprite('salx', true)
    setScrollFactor('salx', 1.1, 1.1)
    setProperty('salx.alpha', 0)

makeLuaSprite('party2', 'school/p2',0, 0);
addLuaSprite('party2', true)
setScrollFactor('party2',1.4, 1.1)
scaleObject('party2',1.6,1.6)

makeLuaSprite('Uhoh2', 'school/Iluminacion', -130 , 0)
    addLuaSprite('Uhoh2', true)
    scaleObject('Uhoh2', 1.9, 1.9)
    setProperty('Uhoh2.alpha', 1)
    
    makeLuaSprite('background2front', 'school/bg2front', -290, -160)
    scaleObject('background2front', 2,2)
    addLuaSprite('background2front', true)
    setProperty('background2front.alpha', 0)
    setBlendMode('background2front','MULTIPLY')
    
    makeAnimatedLuaSprite('sing', 'Sing', 0, 0);
   addAnimationByPrefix('sing','idle','idle-',24, true);
   scaleObject('sing', 1, 1);
   addLuaSprite('sing', false); 
   setObjectCamera('sing', 'other')
   setProperty('sing.angle',-6)
   
   makeAnimatedLuaSprite('sing2', 'Sing', 900, 170);
   addAnimationByPrefix('sing2','idle','idle-',24, true);
   scaleObject('sing2', 1, 1);
   addLuaSprite('sing2', false); 
   setObjectCamera('sing2', 'other')
   setProperty('sing2.angle',8)
   
   makeAnimatedLuaSprite('sing3', 'Sing', 0, 300);
   addAnimationByPrefix('sing3','idle','idle-',24, true);
   scaleObject('sing3', 1, 1);
   addLuaSprite('sing3', false); 
   setObjectCamera('sing3', 'other')
   setProperty('sing3.angle',10)
   
   makeAnimatedLuaSprite('sing4', 'Sing', 800, 500);
   addAnimationByPrefix('sing4','idle','idle-',24, true);
   scaleObject('sing4', 1, 1);
   addLuaSprite('sing4', false); 
   setObjectCamera('sing4', 'other')
   setProperty('sing4.angle',-8)
   
   setProperty('sing.alpha', 0)
        setProperty('sing2.alpha', 0)
        setProperty('sing3.alpha', 0)
        setProperty('sing4.alpha', 0)
        
        makeLuaSprite('darknessss', 'vignette', 0, 0)
    setObjectCamera('darknessss', 'other')
    scaleObject('darknessss', 1, 1)
    addLuaSprite('darknessss', true)
    setProperty('darknessss.alpha', 0)
    
    makeLuaSprite('culo', '', 0, 0)
    setObjectCamera('culo', 'other')
    makeGraphic('culo',1280,720, '000000')
    setProperty('culo.alpha', 1)
    scaleObject('culo',1.66,1.66)
    addLuaSprite('culo', true)
end


function onSongStart()
objectPlayAnimation('tobiasf', 'idle', false)
objectPlayAnimation('tobiasfr', 'idle', false)
triggerEvent('Camera Follow Pos','1050','220')
hideUi(true, true, false, 0, 0.01, 'linear')
	setProperty('iconP1.alpha', 0)
	setProperty('iconP2.alpha', 0)

	setProperty('timeTxt.alpha', 0)
	setProperty('timeBar.alpha', 0)
	setProperty('timeBarBG.alpha', 0)
	setProperty('scoreTxt.visible', false)
setProperty('timeTxt.alpha', 0)
		setProperty('timeBar.alpha', 0)
		setProperty('timeBarBG.alpha', 0)
doTweenY('camerfdfsdsfsdfs','camFollow',620,15,'sineInOut')
end

function hideUi(ui, opponentNotes, playerNotes, target, seconds, tween)

	if tween == '' or tween == nil then
		tween = 'linear'
	end
	
	if ui then
		doTweenAlpha('botPlayTxtA','botPlayTxt', target, seconds, tween)
		if target <= 0.5 then
			midscrollIcon = false
		else
			midscrollIcon = true
		end
	end
	
	if opponentNotes then
		noteTweenAlpha('NoteAlpha0','0', target, seconds, tween)
		noteTweenAlpha('NoteAlpha1','1', target, seconds, tween)
		noteTweenAlpha('NoteAlpha2','2', target, seconds, tween)
		noteTweenAlpha('NoteAlpha3','3', target, seconds, tween)
		
	end
	
	if playerNotes then
		noteTweenAlpha('NoteAlpha4','4', target, seconds, tween)
		noteTweenAlpha('NoteAlpha5','5', target, seconds, tween)
		noteTweenAlpha('NoteAlpha6','6', target, seconds, tween)
		noteTweenAlpha('NoteAlpha7','7', target, seconds, tween)
	end

end

function onBeatHit()
	scaleObject('iconP1', 1, 1)
    scaleObject('iconP2', 1, 1)
    if curBeat %4 == 0 then
    setProperty('ocho.x', math.random(700,1000))
    objectPlayAnimation('ocho', 'idle', true)
    objectPlayAnimation('ochof', 'idle', true)
    end
    end
    

function onStepHit()
if curStep == 64 then
doTweenAlpha('sexo', 'culo', 0.5, 7, 'linear')
end
if curStep == 128 then
setProperty('culo.visible',false)
end
if curStep == 192 then
doTweenX('camerfdfsdsfsdfs','camFollow',1250,5,'sineInOut')
doTweenY('camerfdfsdsfsdfs2','camFollow',725,5,'sineInOut')
end
if curStep == 204 then
		if not downscroll then
			noteTweenY('4', 4, 40, 1.5, 'circOut')
			noteTweenY('5', 5, 40, 1.5, 'circOut')
			noteTweenY('6', 6, 40, 1.5, 'circOut')
			noteTweenY('7', 7, 40, 1.5, 'circOut')
		else
			noteTweenY('4', 4, 570, 1.5, 'circOut')
			noteTweenY('5', 5, 570, 1.5, 'circOut')
			noteTweenY('6', 6, 570, 1.5, 'circOut')
			noteTweenY('7', 7, 570, 1.5, 'circOut')
		end
		end
	if curStep == 224 then
	triggerEvent('Camera Follow Pos','','')
	end
	if curStep == 240 then
	triggerEvent('Camera Follow Pos','','')
	setProperty('isCameraOnForcedPos', true)
	doTweenX('camerfdfsdsfsdfs','camFollow',1450,1,'sineInOut')
	end
	if curStep == 256 then
	if not downscroll then
			doTweenX('iconP1X', 'iconP1Pos', getProperty('iconP1.x')-50, 1, 'expoOut')
			doTweenY('iconP1Y', 'iconP1', getProperty('iconP1.y')-0, 1, 'expoOut')
		else
			doTweenX('iconP1X', 'iconP1Pos', getProperty('iconP1.x')-50, 1, 'expoOut')
			doTweenY('iconP1Y', 'iconP1', getProperty('iconP1.y')+50, 1, 'expoOut')
		end
		doTweenAlpha('blackGameA', 'blackGame', 0, 0.01)
		doTweenAlpha('iconP1A', 'iconP1', 1, 0.6, 'expoOut')
		doTweenAlpha('micA', 'mic', 1, 0.6, 'expoOut')
		doTweenX('camerfdfsdsfsdfs','camFollow',1395,0.5,'sineInOut')
		setProperty('isCameraOnForcedPos', true)
	end
	if curStep == 288 then
	setProperty('isCameraOnForcedPos', true)
	doTweenX('camerfdfsdsfsdfs','camFollow',1410,0.5,'sineInOut')
	end
	if curStep == 320 then
	doTweenX('camerfdfsdsfsdfs','camFollow',1440,0.5,'sineInOut')
	end
	if curStep == 252 then
	doTweenX('camerfdfsdsfsdfs','camFollow',1470,0.5,'sineInOut')
	end
	if curStep == 384 then
	doTweenX('camerfdfsdsfsdfs','camFollow',950,0.5,'sineInOut')
	end
	if curStep == 415 then
	doTweenX('camerfdfsdsfsdfs','camFollow',885,0.5,'sineInOut')
	end
	if curStep == 447 then
	doTweenX('camerfdfsdsfsdfs','camFollow',635,5,'sineInOut')
	end
	if curStep == 486 then
		if not downscroll then
			doTweenX('iconP2X', 'iconP2Pos', 520, 1.5, 'expoOut')
			doTweenY('iconP2Y', 'iconP2', 569, 1.5, 'expoOut')
		else
			doTweenX('iconP2X', 'iconP2Pos', 520, 1.5, 'expoOut')
			doTweenY('iconP2Y', 'iconP2', getProperty('iconP2.y')+50, 1.5, 'expoOut')
		end
		doTweenAlpha('iconP2A', 'iconP2', 1, 0.6, 'expoOut')
		end
		if curStep == 490 then
		hideUi(false, true, false, 1, 1.3, 'linear')
		if not downscroll then
			noteTweenY('0', 0, 40, 1.5, 'circOut')
			noteTweenY('1', 1, 40, 1.5, 'circOut')
			noteTweenY('2', 2, 40, 1.5, 'circOut')
			noteTweenY('3', 3, 40, 1.5, 'circOut')
		else
			noteTweenY('0', 0, 570, 1.5, 'circOut')
			noteTweenY('1', 1, 570, 1.5, 'circOut')
			noteTweenY('2', 2, 570, 1.5, 'circOut')
			noteTweenY('3', 3, 570, 1.5, 'circOut')
		end
		end
	if curStep == 502 then
        objectPlayAnimation('alanp', 'idle', false)
        objectPlayAnimation('masami', 'transition', false)
        objectPlayAnimation('carriep', 'idle', false)
        objectPlayAnimation('tobiasp', 'idle', false)
        objectPlayAnimation('tobiaspr', 'idle', false)
        objectPlayAnimation('aidajop', 'idle', false)
        objectPlayAnimation('aidajopr', 'idle', false)
        objectPlayAnimation('tobiasf', 'idle', true)
objectPlayAnimation('tobiasfr', 'idle', true)
        setProperty('alan.alpha', 0)
        setProperty('alanp.alpha', 1)
        setProperty('carrie.alpha', 0)
        setProperty('carriep.alpha', 0.9)
        setProperty('tobias.alpha', 0)
        setProperty('tobiasp.alpha', 1)
        setProperty('tobiasr.alpha', 0)
        setProperty('tobiaspr.alpha', 0.35)
        setProperty('aidajo.alpha', 0)
        setProperty('aidajop.alpha', 1)
        setProperty('aidajor.alpha', 0)
        setProperty('aidajopr.alpha', 0.35)
        setProperty('carmen.alpha', 0)
        setProperty('carmenp.alpha', 1)
        setProperty('carmenr.alpha', 0)
        setProperty('carmenpr.alpha', 0.35)
    end    
    if curStep == 509 then
    objectPlayAnimation('carrief', 'idle', true)
    end
    if curStep == 512 then
    if not downscroll then
    doTweenAlpha('healthTextA', 'healthText', 1, 0.6, 'expoOut')
    doTweenX('iconP2X', 'iconP2Pos', 340, 2, 'expoOut')
    doTweenX('iconP1X', 'iconP1Pos', getProperty('iconP1.x')+220, 2, 'expoOut')
    doTweenY('health1Y', 'Opo-G', 465, 2, 'expoOut')
    doTweenY('health2Y', 'Opo-R', 465, 2, 'expoOut')
    doTweenY('health3Y', 'Opo-line', 465, 2, 'expoOut')
    doTweenY('rainbowY', 'rainbow', 510, 2, 'expoOut')
    doTweenY('rapperY', 'rapper', 532, 2, 'expoOut')
    else
    doTweenAlpha('healthTextA', 'healthText', 1, 0.6, 'expoOut')
    doTweenX('iconP2X', 'iconP2Pos', 340, 2, 'expoOut')
    doTweenX('iconP1X', 'iconP1Pos', getProperty('iconP1.x')+220, 2, 'expoOut')
    doTweenY('health1Y', 'Opo-G', -85, 2, 'expoOut')
    doTweenY('health2Y', 'Opo-R', -85, 2, 'expoOut')
    doTweenY('health3Y', 'Opo-line', -85, 2, 'expoOut')
    doTweenY('rainbowY', 'rainbow', -40, 2, 'expoOut')
    doTweenY('rapperY', 'rapper', -18, 2, 'expoOut')
    end
    end
    if curStep == 515 then --change this to when they are happy!!
        setProperty('alanp.alpha', 0)
        setProperty('carriep.alpha', 0)
        setProperty('tobiasp.alpha', 0)
        setProperty('tobiaspr.alpha', 0)
        setProperty('ocho.alpha', 0)
        objectPlayAnimation('masami', 'idle happy', true)
        objectPlayAnimation('aidajof', 'idle', true)
        objectPlayAnimation('aidajofr', 'idle', true)
        setProperty('alanf.alpha', 1)
        setProperty('tobiasf.alpha', 1)
        setProperty('tobiasfr.alpha', 0.35)
        setProperty('carrief.alpha', 0.9)
        setProperty('carmenp.alpha', 0)
        setProperty('carmenf.alpha', 1)
        setProperty('carmenpr.alpha', 0)
        setProperty('carmenfr.alpha', 0.35)
        setProperty('aidajop.alpha', 0)
        setProperty('aidajof.alpha', 1)
        setProperty('aidajopr.alpha', 0)
        setProperty('aidajofr.alpha', 0.35)
        setProperty('ochof.alpha', 1)
        doTweenX('camerfdfsdsfsdfs','camFollow',1050,0.1,'sineInOut')
	doTweenY('camerfdfsdsfsdfs2','camFollow',620,0.1,'sineInOut')
    end
    if curStep == 576 then
    setProperty('isCameraOnForcedPos', false)
	doTweenX('camerfdfsdsfsdfs','camFollow',855,0.5,'sineInOut')
	setProperty('cameraSpeed', 1.5)
	end
	if curStep == 747 then
	setProperty('isCameraOnForcedPos', true)
	doTweenX('camerfdfsdsfsdfs','camFollow',1300,0.5,'sineInOut')
	end
	if curStep == 759 then
	setProperty('isCameraOnForcedPos', true)
	setProperty('camFollow.x', 665)
	setProperty('cameraSpeed', 9999)
	setProperty('defaultCamZoom',1.14)
	setProperty('camGame.zoom',1.14)
	setProperty('tobiasf.animation.curAnim.paused', true)     
	setProperty('tobiasfr.animation.curAnim.paused', true)     
        setProperty('aidajof.animation.curAnim.paused', true)     
        setProperty('aidajofr.animation.curAnim.paused', true)     
        setProperty('carrief.animation.curAnim.paused', true)     
        setProperty('alanf.animation.curAnim.paused', true)     
        setProperty('masami.animation.curAnim.paused', true) 
    setProperty('bobert.animation.curAnim.paused', true)
        setProperty('ocho.animation.curAnim.paused', true)     
        setProperty('pennyNjuke.animation.curAnim.paused', true)     
        setProperty('pennyNjuker.animation.curAnim.paused', true)     
        setProperty('carmenf.animation.curAnim.paused', true)     
        setProperty('carmenfr.animation.curAnim.paused', true)     
        setProperty('sal.animation.curAnim.paused', true)     
	initLuaShader('bnw')
    setSpriteShader('background', 'bnw')
    setSpriteShader('party', 'bnw')
    setSpriteShader('party2', 'bnw')
    setSpriteShader('party3', 'bnw')
    setSpriteShader('party4', 'bnw')
    setSpriteShader('ocho', 'bnw')
    setSpriteShader('carrief', 'bnw')
    setSpriteShader('alanf', 'bnw')
    setSpriteShader('aidajof', 'bnw')
    setSpriteShader('aidajofr', 'bnw')
    setSpriteShader('carmenf', 'bnw')
    setSpriteShader('carmenfr', 'bnw')
    setSpriteShader('tobiasf', 'bnw')
    setSpriteShader('tobiasfr', 'bnw')
    setSpriteShader('masami', 'bnw')
    setSpriteShader('wall', 'bnw')
    setSpriteShader('bobert', 'bnw')
    setSpriteShader('carmenf', 'bnw')
    setSpriteShader('carmenfr', 'bnw')
    setSpriteShader('sal', 'bnw')
    setSpriteShader('pennyNjuke', 'bnw')
    setSpriteShader('pennyNjuker', 'bnw')
    setSpriteShader('boyfriend', 'bnw')
    setSpriteShader('bfPhantom', 'bnw')
    setSpriteShader('part' .. f, 'bnw')
    setSpriteShader('part2' .. f2, 'bnw')
    continue = false;
	end
	if curStep == 768 then
	setProperty('cameraSpeed', 1.5)
	setProperty('isCameraOnForcedPos', false)
	doTweenX('camerfdfsdsfsdfs','camFollow',855,0.5,'sineInOut')
	setProperty('tobiasf.animation.curAnim.paused', false)     
	setProperty('tobiasfr.animation.curAnim.paused', false)     
        setProperty('aidajof.animation.curAnim.paused', false)     
        setProperty('aidajofr.animation.curAnim.paused', false)     
        setProperty('carrief.animation.curAnim.paused', false)     
        setProperty('alanf.animation.curAnim.paused', false)     
        setProperty('masami.animation.curAnim.paused', false) 
    setProperty('bobert.animation.curAnim.paused', false)
        setProperty('ocho.animation.curAnim.paused', false)     
        setProperty('pennyNjuke.animation.curAnim.paused', false)     
        setProperty('pennyNjuker.animation.curAnim.paused', false)     
        setProperty('carmenf.animation.curAnim.paused', false)     
        setProperty('carmenfr.animation.curAnim.paused', false)     
        setProperty('sal.animation.curAnim.paused', false)     
	removeSpriteShader('background')
	removeSpriteShader('party')
	removeSpriteShader('party2')
	removeSpriteShader('party3')
	removeSpriteShader('party4')
	removeSpriteShader('ocho')
	removeSpriteShader('carrief')
	removeSpriteShader('alanf')
	removeSpriteShader('aidajof')
	removeSpriteShader('aidajofr')
	removeSpriteShader('carmenf')
	removeSpriteShader('carmenfr')
	removeSpriteShader('tobiasf')
	removeSpriteShader('tobiasfr')
	removeSpriteShader('masami')
	removeSpriteShader('wall')
	removeSpriteShader('bobert')
	removeSpriteShader('sal')
	removeSpriteShader('pennyNjuke')
	removeSpriteShader('pennyNjuke')
	removeSpriteShader('pennyNjuker')
	removeSpriteShader('boyfriend')
	removeSpriteShader('bfPhantom')
	removeSpriteShader('part' .. f)
	removeSpriteShader('part2' .. f)
	continue = true;
	end
	if curStep == 800 then
	setProperty('isCameraOnForcedPos', true)
	doTweenX('camerfdfsdsfsdfs','camFollow',1050,1,'sineInOut')
	end
	if curStep == 826 then
	setProperty('isCameraOnForcedPos', true)
	setProperty('camFollow.x', 765)
	setProperty('cameraSpeed', 9999)
	setProperty('defaultCamZoom',1.14)
	setProperty('camGame.zoom',1.14)
	setProperty('camGame.zoom',1.14)
	setProperty('tobiasf.animation.curAnim.paused', true)     
	setProperty('tobiasfr.animation.curAnim.paused', true)     
        setProperty('aidajof.animation.curAnim.paused', true)     
        setProperty('aidajofr.animation.curAnim.paused', true)     
        setProperty('carrief.animation.curAnim.paused', true)     
        setProperty('alanf.animation.curAnim.paused', true)     
        setProperty('masami.animation.curAnim.paused', true) 
    setProperty('bobert.animation.curAnim.paused', true)
        setProperty('ocho.animation.curAnim.paused', true)     
        setProperty('pennyNjuke.animation.curAnim.paused', true)    
        setProperty('pennyNjuker.animation.curAnim.paused', true)    
setProperty('carmenf.animation.curAnim.paused', true)     
setProperty('carmenfr.animation.curAnim.paused', true)     
        setProperty('sal.animation.curAnim.paused', true)      
	initLuaShader('bnw')
    setSpriteShader('background', 'bnw')
    setSpriteShader('party', 'bnw')
    setSpriteShader('party2', 'bnw')
    setSpriteShader('party3', 'bnw')
    setSpriteShader('party4', 'bnw')
    setSpriteShader('ocho', 'bnw')
    setSpriteShader('carrief', 'bnw')
    setSpriteShader('alanf', 'bnw')
    setSpriteShader('aidajof', 'bnw')
    setSpriteShader('aidajofr', 'bnw')
    setSpriteShader('carmenf', 'bnw')
    setSpriteShader('carmenfr', 'bnw')
    setSpriteShader('tobiasf', 'bnw')
    setSpriteShader('tobiasfr', 'bnw')
    setSpriteShader('masami', 'bnw')
    setSpriteShader('wall', 'bnw')
    setSpriteShader('sal', 'bnw')
    setSpriteShader('bobert', 'bnw')
    setSpriteShader('pennyNjuke', 'bnw')
    setSpriteShader('pennyNjuker', 'bnw')
    setSpriteShader('boyfriend', 'bnw')
    setSpriteShader('bfPhantom', 'bnw')
    setSpriteShader('part' .. f, 'bnw')
    setSpriteShader('part2' .. f2, 'bnw')
    continue = false;
	end
	if curStep == 832 then
	setProperty('cameraSpeed', 1.5)
	setProperty('isCameraOnForcedPos', false)
	doTweenX('camerfdfsdsfsdfs','camFollow',855,0.5,'sineInOut')
	setProperty('tobiasf.animation.curAnim.paused', false)     
	setProperty('tobiasfr.animation.curAnim.paused', false)     
        setProperty('aidajof.animation.curAnim.paused', false)     
        setProperty('aidajofr.animation.curAnim.paused', false)     
        setProperty('carrief.animation.curAnim.paused', false)     
        setProperty('alanf.animation.curAnim.paused', false)     
        setProperty('masami.animation.curAnim.paused', false) 
    setProperty('bobert.animation.curAnim.paused', false)
        setProperty('ocho.animation.curAnim.paused', false)     
        setProperty('pennyNjuke.animation.curAnim.paused', false)   
        setProperty('pennyNjuker.animation.curAnim.paused', false)   
  setProperty('carmenf.animation.curAnim.paused', false)     
  setProperty('carmenfr.animation.curAnim.paused', false)     
        setProperty('sal.animation.curAnim.paused', false)     
	removeSpriteShader('background')
	removeSpriteShader('party')
	removeSpriteShader('party2')
	removeSpriteShader('party3')
	removeSpriteShader('party4')
	removeSpriteShader('ocho')
	removeSpriteShader('carrief')
	removeSpriteShader('alanf')
	removeSpriteShader('aidajof')
	removeSpriteShader('aidajofr')
	removeSpriteShader('carmenf')
	removeSpriteShader('carmenfr')
	removeSpriteShader('tobiasf')
	removeSpriteShader('tobiasfr')
	removeSpriteShader('masami')
	removeSpriteShader('wall')
	removeSpriteShader('bobert')
	removeSpriteShader('pennyNjuke')
	removeSpriteShader('pennyNjuker')
	removeSpriteShader('boyfriend')
	removeSpriteShader('bfPhantom')
	removeSpriteShader('sal')
	removeSpriteShader('part' .. f)
	removeSpriteShader('part2' .. f)
	continue = true;
	end
	if curStep == 934 then
	setProperty('isCameraOnForcedPos', true)
	setProperty('camFollow.x', 715)
	setProperty('cameraSpeed', 9999)
	setProperty('defaultCamZoom',1.14)
	setProperty('camGame.zoom',1.14)
	setProperty('camGame.zoom',1.14)
	setProperty('tobiasf.animation.curAnim.paused', true)     
	setProperty('tobiasfr.animation.curAnim.paused', true)     
        setProperty('aidajof.animation.curAnim.paused', true)     
        setProperty('aidajofr.animation.curAnim.paused', true)     
        setProperty('carrief.animation.curAnim.paused', true)     
        setProperty('alanf.animation.curAnim.paused', true)     
        setProperty('masami.animation.curAnim.paused', true) 
    setProperty('bobert.animation.curAnim.paused', true)
        setProperty('ocho.animation.curAnim.paused', true)     
        setProperty('pennyNjuke.animation.curAnim.paused', true)     
        setProperty('pennyNjuker.animation.curAnim.paused', true)     
        setProperty('carmenf.animation.curAnim.paused', true)     
        setProperty('carmenfr.animation.curAnim.paused', true)     
        setProperty('sal.animation.curAnim.paused', true)     
	initLuaShader('bnw')
    setSpriteShader('background', 'bnw')
    setSpriteShader('party', 'bnw')
    setSpriteShader('party2', 'bnw')
    setSpriteShader('party3', 'bnw')
    setSpriteShader('party4', 'bnw')
    setSpriteShader('ocho', 'bnw')
    setSpriteShader('carrief', 'bnw')
    setSpriteShader('alanf', 'bnw')
    setSpriteShader('aidajof', 'bnw')
    setSpriteShader('aidajofr', 'bnw')
    setSpriteShader('carmenf', 'bnw')
    setSpriteShader('carmenfr', 'bnw')
    setSpriteShader('tobiasf', 'bnw')
    setSpriteShader('tobiasfr', 'bnw')
    setSpriteShader('masami', 'bnw')
    setSpriteShader('wall', 'bnw')
    setSpriteShader('bobert', 'bnw')
    setSpriteShader('sal', 'bnw')
    setSpriteShader('pennyNjuke', 'bnw')
    setSpriteShader('pennyNjuker', 'bnw')
    setSpriteShader('boyfriend', 'bnw')
    setSpriteShader('bfPhantom', 'bnw')
    setSpriteShader('part' .. f, 'bnw')
    setSpriteShader('part2' .. f2, 'bnw')
    continue = false;
	end
	if curStep == 943 then
	setProperty('cameraSpeed', 9999)
	setProperty('isCameraOnForcedPos', false)
	setProperty('tobiasf.animation.curAnim.paused', false)     
	setProperty('tobiasfr.animation.curAnim.paused', false)     
        setProperty('aidajof.animation.curAnim.paused', false)     
        setProperty('aidajofr.animation.curAnim.paused', false)     
        setProperty('carrief.animation.curAnim.paused', false)     
        setProperty('alanf.animation.curAnim.paused', false)     
        setProperty('masami.animation.curAnim.paused', false) 
    setProperty('bobert.animation.curAnim.paused', false)
        setProperty('ocho.animation.curAnim.paused', false)     
        setProperty('pennyNjuke.animation.curAnim.paused', false)   
        setProperty('pennyNjuker.animation.curAnim.paused', false)   
  setProperty('carmenf.animation.curAnim.paused', false)    
 setProperty('carmenfr.animation.curAnim.paused', false)     
        setProperty('sal.animation.curAnim.paused', false)     
	removeSpriteShader('background')
	removeSpriteShader('party')
	removeSpriteShader('party2')
	removeSpriteShader('party3')
	removeSpriteShader('party4')
	removeSpriteShader('ocho')
	removeSpriteShader('carrief')
	removeSpriteShader('alanf')
	removeSpriteShader('aidajof')
	removeSpriteShader('aidajofr')
	removeSpriteShader('carmenf')
	removeSpriteShader('carmenfr')
	removeSpriteShader('tobiasf')
	removeSpriteShader('tobiasfr')
	removeSpriteShader('masami')
	removeSpriteShader('wall')
	removeSpriteShader('bobert')
	removeSpriteShader('pennyNjuke')
	removeSpriteShader('pennyNjuker')
	removeSpriteShader('boyfriend')
	removeSpriteShader('bfPhantom')
	removeSpriteShader('sal')
	removeSpriteShader('part' .. f)
	removeSpriteShader('part2' .. f)
	continue = true;
	end
	if curStep == 991 then
	setProperty('cameraSpeed', 1.5)
	end
	if curStep == 1148 then
	setProperty('isCameraOnForcedPos', true)
	doTweenX('camerfdfsdsfsdfs','camFollow',665,0.25,'sineInOut')
	end
	if curStep == 1151 then
	setProperty('isCameraOnForcedPos', false)
	doTweenX('camerfdfsdsfsdfs','camFollow',855,0.25,'sineInOut')
	end
	if curStep == 1238 then
	setProperty('isCameraOnForcedPos', true)
	doTweenX('camerfdfsdsfsdfs','camFollow',1440,2,'sineInOut')
	end
	if curStep == 1268 then
	setProperty('isCameraOnForcedPos', true)
	doTweenX('camerfdfsdsfsdfs','camFollow',1400,0.5,'sineInOut')
	end
	if curStep == 1280 then
	makeLuaSprite('flash', '', 0, 0);
        makeGraphic('flash',1,1,'000000')
	      addLuaSprite('flash', true);
	      setLuaSpriteScrollFactor('flash',0,0)
	      setProperty('flash.scale.x',0.2)
	      setProperty('flash.scale.y',0.2)
	      setProperty('flash.alpha',0)
	addLuaSprite('flash', true);
	setObjectCamera('flash', 'camHUD')
	end 
	if curStep == 1400 then
setProperty('background.alpha', 0)
	setProperty('wall.alpha', 0)
	setProperty('party.alpha', 0)
	setProperty('party2.alpha', 0)
	setProperty('party3.alpha', 0)
	setProperty('party4.alpha', 0)
	setProperty('bobert.alpha', 0)
	setProperty('ocho.alpha', 0)
	setProperty('Uhoh2.alpha', 0)
	setProperty('sal.alpha', 0)
	setProperty('alanf.alpha', 0)
        setProperty('tobiasf.alpha', 0)
        setProperty('tobiasfr.alpha', 0)
        setProperty('carrief.alpha', 0)
        setProperty('carmenp.alpha', 0)
        setProperty('carmenf.alpha', 0)
        setProperty('carmenpr.alpha', 0)
        setProperty('carmenfr.alpha', 0)
        setProperty('aidajop.alpha', 0)
        setProperty('aidajof.alpha', 0)
        setProperty('aidajopr.alpha', 0)
        setProperty('aidajofr.alpha', 0)
        setProperty('ochof.alpha', 0)
        setProperty('pennyNjuke.alpha', 0)
        setProperty('pennyNjuker.alpha', 0) 
	end
	if curStep == 1407 then
	setProperty('isCameraOnForcedPos', true)
	setProperty('dad.color', getColorFromHex('707090'))
	setProperty('camFollow.x', 665)
	setProperty('defaultCamZoom',1.14)
	setProperty('camGame.zoom',1.14)
	doTweenX('camerfdfsdsfsdfs','camFollow',855,6,'sineInOut')
	playAnim("masami", "corrupted")
	setProperty('background.alpha', 0)
	setProperty('wall.alpha', 0)
	setProperty('party.alpha', 0)
	setProperty('party2.alpha', 0)
	setProperty('party3.alpha', 0)
	setProperty('party4.alpha', 0)
	setProperty('bobert.alpha', 0)
	setProperty('ocho.alpha', 0)
	setProperty('Uhoh2.alpha', 0)
	setProperty('sal.alpha', 0)
	setProperty('alanf.alpha', 0)
        setProperty('tobiasf.alpha', 0)
        setProperty('tobiasfr.alpha', 0)
        setProperty('carrief.alpha', 0)
        setProperty('carmenp.alpha', 0)
        setProperty('carmenf.alpha', 0)
        setProperty('carmenpr.alpha', 0)
        setProperty('carmenfr.alpha', 0)
        setProperty('aidajop.alpha', 0)
        setProperty('aidajof.alpha', 0)
        setProperty('aidajopr.alpha', 0)
        setProperty('aidajofr.alpha', 0)
        setProperty('ochof.alpha', 0)
        setProperty('pennyNjuke.alpha', 0)
        setProperty('pennyNjuker.alpha', 0)
	setProperty('background2.alpha', 1)
	setProperty('background2front.alpha', 0.7)
	setProperty('wall2.alpha', 1)
	setProperty('tobiasx.alpha', 1)
	setProperty('tobiasxr.alpha', 0.35)
	setProperty('alanx.alpha', 1)
	setProperty('pennyNjukedark.alpha', 1)
	setProperty('pennyNjukedarkr.alpha', 0.35)
	setProperty('aidajox.alpha', 1)
	setProperty('aidajoxr.alpha', 0.35)
	setProperty('carriex.alpha', 1)
	setProperty('salx.alpha', 1)
	setProperty('bobertx.alpha', 1)
	setProperty('carmenx.alpha', 1)
	setProperty('carmenxr.alpha', 0.35)
	setProperty('ochox.alpha', 1)
	setProperty('healthBarScript.alpha', 0.5)
	setProperty('glitch1.alpha', 0.5)
	setProperty('rapper.alpha', 0)
			setProperty('theGlitch2.alpha', 0.5)
	setProperty('masami.color', getColorFromHex('0xFF8B9AB9'))
	setProperty('ochox.color', getColorFromHex('0xFF8B9AB9'))
	setProperty('carmenx.color', getColorFromHex('0xFF8B9AB9'))
	setProperty('boyfriend.color', getColorFromHex('0xFF8B9AB9'))
	setProperty('dad.color', getColorFromHex('707090'))
	setProperty('aidajox.color', getColorFromHex('0xFFA3A5A9'))
	setProperty('salx.color', getColorFromHex('707090'))
	setProperty('bobertx.color', getColorFromHex('303059'))
	setProperty('carriex.color', getColorFromHex('0xFF7C7C7C'))
	end
	if curStep == 1408 then
	setProperty('dad.color', getColorFromHex('707090'))
	end
	if curStep == 1484 then
	setProperty('cameraSpeed', 3)
	setProperty('isCameraOnForcedPos', true)
	doTweenX('camerfdfsdsfsdfs','camFollow',1300,0.5,'sineInOut')
	end
	if curStep == 1492 then
	setProperty('isCameraOnForcedPos', true)
	doTweenX('camerfdfsdsfsdfs','camFollow',855,0.5,'sineInOut')
	end
	if curStep == 1503 then
	setProperty('cameraSpeed', 1.5)
	setProperty('isCameraOnForcedPos', true)
	doTweenX('camerfdfsdsfsdfs','camFollow',755,0.5,'sineInOut')
	end
	if curStep == 1523 then
	setProperty('isCameraOnForcedPos', true)
	doTweenX('camerfdfsdsfsdfs','camFollow',655,0.5,'sineInOut')
	end
if curStep == 1535 then
setProperty('cameraSpeed', 3)
doTweenX('camerfdfsdsfsdfs','camFollow',1500,0.1,'sineInOut')
doTweenAlpha('masamiAlpha', 'masami', 0, 1.5, 'sineInOut')  
end
if curStep == 1564 then
setProperty('isCameraOnForcedPos', true)
setProperty('cameraSpeed', 9999)
	setProperty('camFollow.x', 665)
	setProperty('defaultCamZoom',1.14)
	setProperty('camGame.zoom',1.14)
end
if curStep == 1567 then
setProperty('cameraSpeed', 3)
doTweenX('camerfdfsdsfsdfs','camFollow',1500,0.1,'sineInOut')
doTweenAlpha('alanxAlpha', 'alanx', 0, 1.5, 'sineInOut')   
doTweenAlpha('carmenxAlpha', 'carmenx', 0, 1.5, 'sineInOut')   
doTweenAlpha('carmenxrAlpha', 'carmenxr', 0, 1.5, 'sineInOut')   
end
if curStep == 1595 then
setProperty('isCameraOnForcedPos', true)
setProperty('cameraSpeed', 9999)
	setProperty('camFollow.x', 665)
	setProperty('defaultCamZoom',1.14)
	setProperty('camGame.zoom',1.14)
end
if curStep == 1599 then
setProperty('cameraSpeed', 3)
doTweenX('camerfdfsdsfsdfs','camFollow',1500,0.1,'sineInOut')
doTweenAlpha('aidajoxAlpha', 'aidajox', 0, 1.5, 'sineInOut')   
doTweenAlpha('aidajoxrAlpha', 'aidajoxr', 0, 1.5, 'sineInOut')   
doTweenAlpha('salxAlpha', 'salx', 0, 1.5, 'sineInOut')   
end
if curStep == 1611 then
setProperty('cameraSpeed', 3)
doTweenX('camerfdfsdsfsdfs','camFollow',855,0.1,'sineInOut')
doTweenAlpha('tobiasxAlpha', 'tobiasx', 0, 1.5, 'sineInOut')   
doTweenAlpha('tobiasxrAlpha', 'tobiasxr', 0, 1.5, 'sineInOut')   
doTweenAlpha('bobertxAlpha', 'bobertx', 0, 1.5, 'sineInOut')   
	end
	if curStep == 1619 then
setProperty('cameraSpeed', 3)
doTweenX('camerfdfsdsfsdfs','camFollow',1500,0.1,'sineInOut')
end
if curStep == 1627 then
setProperty('cameraSpeed', 3)
doTweenX('camerfdfsdsfsdfs','camFollow',855,0.1,'sineInOut')
	end
	if curStep == 1632 then
	doTweenAlpha('carriexAlpha', 'carriex', 0, 1.5, 'sineInOut')   
	end
	if curStep == 1636 then
setProperty('cameraSpeed', 3)
doTweenX('camerfdfsdsfsdfs','camFollow',1500,0.1,'sineInOut')
end
if curStep == 1644 then
setProperty('cameraSpeed', 3)
doTweenX('camerfdfsdsfsdfs','camFollow',855,0.1,'sineInOut')
doTweenAlpha('ochoAlpha', 'ochox', 0, 1.4, 'sineInOut')   
	end
	if curStep == 1647 then
	doTweenAlpha('pennyNjukedarkAlpha', 'pennyNjukedark', 0, 1.4, 'sineInOut')   
	doTweenAlpha('pennyNjukedarkrAlpha', 'pennyNjukedarkr', 0, 1.4, 'sineInOut')   
	end
	if curStep == 1664 then
	makeVideoSprite('f', 'newcutscene', -330, -180, 1, 'camGame', true)
	setObjectCamera('f', 'camHUD')
	setObjectOrder('f', getObjectOrder('strumLineNotes')+1)
	playVideoSprite('f')
	setProperty('f.visible', true);
        doTweenX('camerfdfsdsfsdfs','camFollow',795,0.1,'sineInOut')
        end
        if curStep == 1824 then
        setProperty('background2front.alpha', 1)
        setProperty('secondtopgoop.alpha', 1)
        setProperty('topgoop.alpha', 1)
        setProperty('droplet.alpha', 1)
        setProperty('droplet2.alpha', 1)
        setProperty('sinkgoop.alpha', 1)
        setProperty('mic.alpha', 0)
        setProperty('gun.alpha', 1)
        end
        if curStep == 1856 then
        doTweenX('camerfdfsdsfsdfs','camFollow',755,0.1,'sineInOut')
        end
        if curStep == 1888 then
        setProperty('isCameraOnForcedPos', false)
        end
        if curStep == 1918 then
        doTweenAlpha('sing', 'sing', 1, 1, 'linear')
        setProperty('isCameraOnForcedPos', true)
        doTweenX('camerfdfsdsfsdfs','camFollow',1420,0.5,'sineInOut')
        end
        if curStep == 1922 then
        doTweenAlpha('sing2', 'sing2', 1, 1, 'linear')
        end
        if curStep == 1926 then
        doTweenAlpha('sing3', 'sing3', 1, 1, 'linear')
        end
        if curStep == 1930 then
        doTweenAlpha('sing4', 'sing4', 1, 1, 'linear')
        end
        if curStep == 1936 then
        doTweenX('camerfdfsdsfsdfs','camFollow',1440,0.5,'sineInOut')
        end
        if curStep == 1943 then
        doTweenX('camerfdfsdsfsdfs','camFollow',1470,0.5,'sineInOut')
        end
        if curStep == 1952 then
        setProperty('isCameraOnForcedPos', false)
        end
        if curStep == 1956 then
        doTweenAlpha('sing', 'sing', 0, 0.4, 'linear')
        doTweenAlpha('sing2', 'sing2', 0, 0.4, 'linear')
        doTweenAlpha('sing3', 'sing3', 0, 0.4, 'linear')
        doTweenAlpha('sing4', 'sing4', 0, 0.4, 'linear')
        end
        if curStep == 2016 then
        setProperty('isCameraOnForcedPos', true)
        doTweenX('camerfdfsdsfsdfs','camFollow',755,0.1,'sineInOut')
        end
        if curStep == 2032 then
        doTweenX('camerfdfsdsfsdfs','camFollow',725,0.1,'sineInOut')
        end
        if curStep == 2048 then
        doTweenX('camerfdfsdsfsdfs','camFollow',695,0.1,'sineInOut')
        end
        if curStep == 2080 then
        setProperty('cameraSpeed', 999)
        setProperty('isCameraOnForcedPos', false)
        end
        if curStep == 2144 then
        setProperty('isCameraOnForcedPos', true)
setProperty('cameraSpeed', 3)
doTweenX('camerfdfsdsfsdfs','camFollow',1430,0.1,'sineInOut')
end
if curStep == 2176 then
setProperty('cameraSpeed', 3)
doTweenX('camerfdfsdsfsdfs','camFollow',1442,0.1,'sineInOut')
end
if curStep == 2208 then
doTweenX('camerfdfsdsfsdfs','camFollow',665,0.1,'sineInOut')
end
if curStep == 2218 then
doTweenX('camerfdfsdsfsdfs','camFollow',705,0.1,'sineInOut')
end
if curStep == 2224 then
        setProperty('isCameraOnForcedPos', false)
        end
        if curStep == 2243 then
        setProperty('isCameraOnForcedPos', true)
setProperty('cameraSpeed', 3)
doTweenX('camerfdfsdsfsdfs','camFollow',1400,0.1,'sineInOut')
end
if curStep == 2304 then
setProperty('isCameraOnForcedPos', false)
end
if curStep == 2336 then
setProperty('isCameraOnForcedPos', true)
doTweenX('camerfdfsdsfsdfs','camFollow',1420,0.1,'sineInOut')
end
if curStep == 2368 then
setProperty('isCameraOnForcedPos', false)
end
if curStep == 2372 then
setProperty('isCameraOnForcedPos', false)
end
if curStep == 2432 then
setProperty('isCameraOnForcedPos', true)
doTweenX('camerfdfsdsfsdfs','camFollow',1420,0.1,'sineInOut')
end
if curStep == 2465 then
setProperty('isCameraOnForcedPos', true)
doTweenX('camerfdfsdsfsdfs','camFollow',1405,0.2,'sineInOut')
end
if curStep == 2528 then
setProperty('isCameraOnForcedPos', true)
doTweenX('camerfdfsdsfsdfs','camFollow',1470,0.2,'sineInOut')
end
if curStep == 2560 then
setProperty('isCameraOnForcedPos', true)
doTweenX('camerfdfsdsfsdfs','camFollow',1500,0.5,'sineInOut')
end
if curStep == 2584 then
setProperty('isCameraOnForcedPos', false)
end
if curStep == 2656 then
        setProperty('isCameraOnForcedPos', true)
        doTweenX('camerfdfsdsfsdfs','camFollow',695,0.5,'sineInOut')
        end
        if curStep == 2688 then
        setProperty('isCameraOnForcedPos', true)
        doTweenX('camerfdfsdsfsdfs','camFollow',625,0.5,'sineInOut')
        end
        if curStep == 2720 then
        setProperty('masami.color', getColorFromHex('FFFFFF'))
        setProperty('boyfriend.color', getColorFromHex('FFFFFF'))
        setProperty('dad.color', getColorFromHex('FFFFFF'))
        setProperty('mic.alpha', 1)
        setProperty('gun.alpha', 0)
        setProperty('Opo-G.alpha', 1)
		setProperty('Opo-R.alpha', 1)
		setProperty('Opo-line.alpha', 1)
		setProperty('rapper.alpha', 1)
		objectPlayAnimation('masami', 'idle happy', true)
		setProperty('healthBarScript.alpha', 0)
	setProperty('glitch1.alpha', 0)
			setProperty('theGlitch2.alpha', 0)
        setProperty('background.alpha', 1)
	setProperty('wall.alpha', 1)
	setProperty('party.alpha', 1)
	setProperty('party2.alpha', 1)
	setProperty('party3.alpha', 1)
	setProperty('party4.alpha', 1)
	setProperty('bobert.alpha', 1)
	setProperty('ocho.alpha', 1)
	setProperty('Uhoh2.alpha', 1)
	setProperty('sal.alpha', 1)
	setProperty('masami.alpha', 1)
	setProperty('alanf.alpha', 1)
        setProperty('tobiasf.alpha', 1)
        setProperty('tobiasfr.alpha', 0.35)
        setProperty('carrief.alpha', 1)
        setProperty('carmenf.alpha', 1)
        setProperty('carmenfr.alpha', 0.35)
        setProperty('aidajof.alpha', 1)
        setProperty('aidajofr.alpha', 0.35)
        setProperty('pennyNjuke.alpha', 1)
        setProperty('pennyNjuker.alpha', 0.35)
        setProperty('background2.alpha', 0)
        setProperty('background2front.alpha', 0)
        setProperty('wall2.alpha', 0)
        setProperty('secondtopgoop.alpha', 0)
        setProperty('topgoop.alpha', 0)
        setProperty('droplet.alpha', 0)
        setProperty('droplet2.alpha', 0)
        setProperty('sinkgoop.alpha', 0)
        setProperty('darknessss.alpha', 1)
doTweenX('camerfdfsdsfsdfs','camFollow',1400,0.1,'sineInOut')
end
if curStep == 2848 then
playAnim("masami", "corrupted")
setProperty('mic.alpha', 0)
        setProperty('gun.alpha', 1)
setProperty('darknessss.alpha', 0)
setProperty('Opo-G.alpha', 0)
		setProperty('Opo-R.alpha', 0)
		setProperty('Opo-line.alpha', 0)
		setProperty('rapper.alpha', 0)
		setProperty('healthBarScript.alpha', 1)
	setProperty('glitch1.alpha', 1)
			setProperty('theGlitch2.alpha', 1)
setProperty('background2.alpha', 1)
setProperty('background2front.alpha', 0.7)
	setProperty('wall2.alpha', 1)
	setProperty('tobiasx.alpha', 1)
	setProperty('tobiasxr.alpha', 0.35)
	setProperty('alanx.alpha', 1)
	setProperty('pennyNjukedark.alpha', 1)
	setProperty('pennyNjukedarkr.alpha', 0.35)
	setProperty('aidajox.alpha', 1)
	setProperty('aidajoxr.alpha', 0.35)
	setProperty('carriex.alpha', 1)
	setProperty('carmenx.alpha', 1)
	setProperty('carmenxr.alpha', 0.35)
	setProperty('bobertx.alpha', 1)
	setProperty('salx.alpha', 1)
	setProperty('ochox.alpha', 1)
	setProperty('background.alpha', 0)
	setProperty('wall.alpha', 0)
	setProperty('party.alpha', 0)
	setProperty('party2.alpha', 0)
	setProperty('party3.alpha', 0)
	setProperty('party4.alpha', 0)
	setProperty('bobert.alpha', 0)
	setProperty('ocho.alpha', 0)
	setProperty('Uhoh2.alpha', 0)
	setProperty('sal.alpha', 0)
	setProperty('alanf.alpha', 0)
        setProperty('tobiasf.alpha', 0)
        setProperty('tobiasfr.alpha', 0)
        setProperty('carrief.alpha', 0)
        setProperty('carmenf.alpha', 0)
        setProperty('carmenfr.alpha', 0)
        setProperty('aidajof.alpha', 0)
        setProperty('aidajofr.alpha', 0)
        setProperty('pennyNjuke.alpha', 0)
        setProperty('pennyNjuker.alpha', 0)
	setProperty('masami.color', getColorFromHex('0xFF8B9AB9'))
	setProperty("boyfriend.color", getColorFromHex("707090"))
	setProperty('dad.color', getColorFromHex('707090'))
	setProperty('aidajox.color', getColorFromHex('0xFFA3A5A9'))
	setProperty('carriex.color', getColorFromHex('0xFF7C7C7C'))
        doTweenX('camerfdfsdsfsdfs','camFollow',755,3.5,'sineInOut')
        end
        if curStep == 2896 then
        doTweenX('camerfdfsdsfsdfs','camFollow',725,0.1,'sineInOut')
        end
        if curStep == 2912 then
        doTweenX('camerfdfsdsfsdfs','camFollow',695,0.1,'sineInOut')
        end
        if curStep == 2924 then
setProperty('isCameraOnForcedPos', true)
doTweenX('camerfdfsdsfsdfs','camFollow',1420,0.1,'sineInOut')
end
if curStep == 2931 then
        doTweenX('camerfdfsdsfsdfs','camFollow',695,0.1,'sineInOut')
        end
        if curStep == 2940 then
setProperty('isCameraOnForcedPos', true)
doTweenX('camerfdfsdsfsdfs','camFollow',1420,0.1,'sineInOut')
end
if curStep == 2947 then
        doTweenX('camerfdfsdsfsdfs','camFollow',695,0.1,'sineInOut')
        end
        if curStep == 2956 then
setProperty('isCameraOnForcedPos', true)
doTweenX('camerfdfsdsfsdfs','camFollow',1420,0.1,'sineInOut')
end
if curStep == 2964 then
        doTweenX('camerfdfsdsfsdfs','camFollow',695,0.1,'sineInOut')
        end
        if curStep == 3040 then
        setProperty("dad.color", getColorFromHex("707090"))
        setProperty('background2front.alpha', 1)
        setProperty('secondtopgoop.alpha', 1)
        setProperty('topgoop.alpha', 1)
        setProperty('droplet.alpha', 1)
        setProperty('droplet2.alpha', 1)
        setProperty('sinkgoop.alpha', 1)
        setProperty('tobiasx.alpha', 0)
        setProperty('tobiasxr.alpha', 0)
	setProperty('alanx.alpha', 0)
	setProperty('pennyNjukedark.alpha', 0)
	setProperty('pennyNjukedarkr.alpha', 0)
	setProperty('aidajox.alpha', 0)
	setProperty('aidajoxr.alpha', 0)
	setProperty('carriex.alpha', 0)
	setProperty('masami.alpha', 0)
	setProperty('carmenx.alpha', 0)
	setProperty('carmenxr.alpha', 0)
	setProperty('bobertx.alpha', 0)
	setProperty('salx.alpha', 0)
	setProperty('ochox.alpha', 0)
        end
	end

    function onTweenCompleted(tag)
if tag == 'alanY' then 
        doTweenY('alanY2', 'alan', 175, 1, 'sineInOut')
    end
    if tag == 'alanY2' then 
        doTweenY('alanY', 'alan', 200, 1, 'sineInOut')
    end 
    if tag == 'alanpY' then 
        doTweenY('alanpY2', 'alanp', 175, 1, 'sineInOut')
    end
    if tag == 'alanpY2' then 
        doTweenY('alanpY', 'alanp', 200, 1, 'sineInOut')
    end 
    if tag == 'alanfY' then 
        doTweenY('alanfY2', 'alanf', 175, 1, 'sineInOut')
    end
    if tag == 'alanfY2' then 
        doTweenY('alanfY', 'alanf', 200, 1, 'sineInOut')
    end 
    if tag == 'alanxY' then 
        doTweenY('alanxY2', 'alanx', 175, 1, 'sineInOut')
    end
    if tag == 'alanxY2' then 
        doTweenY('alanxY', 'alanx', 200, 1, 'sineInOut')
    end 
    end
    
local elapsedTotal = 0.0;
local continue = true;
function onUpdate(elapsed)
	elapsedTotal = elapsedTotal + elapsed;
	
	if continue == true then
	setProperty("carrie.y", getProperty("carrie.y") + (math.cos(elapsedTotal * 3.51) * 0.6))
	setProperty("carriep.y", getProperty("carriep.y") + (math.cos(elapsedTotal * 3.51) * 0.6))
	setProperty("carrief.y", getProperty("carrief.y") + (math.cos(elapsedTotal * 3.51) * 0.6))
	setProperty("carriex.y", getProperty("carriex.y") + (math.cos(elapsedTotal * 3.51) * 0.6))
	else
	setProperty("carrie.y", getProperty("carrie.y") + (math.cos(0 * 0) * 0))
	setProperty("carriep.y", getProperty("carriep.y") + (math.cos(0 * 0) * 0))
	setProperty("carrief.y", getProperty("carrief.y") + (math.cos(0 * 0) * 0))
	setProperty("carriex.y", getProperty("carriex.y") + (math.cos(0 * 0) * 0))
	end
	
	setProperty("masami.x", getProperty("masami.x") - (math.sin(elapsedTotal * 1) * 0.3))
	setProperty("masami.y", getProperty("masami.y") + (math.cos(elapsedTotal * 0.7) * 0.3))
	end