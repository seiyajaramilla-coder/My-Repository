-- RECREATE BY SEBASYTXD ---
local f = 1  
local glitch = false  

function onStepHit()
    if curStep <= 1282 then -- Aparecen en cada paso
        Particle()
    end
end

function Particle()
    local songPos = getSongPosition()
    local currentBeat = (songPos / 500)

    f = f + 1
    local posX = math.random(-800, 3200)
    local posY = math.random(-100, 300)

    makeLuaSprite('part' .. f, 'particle', posX, posY)

    local fixedSize = 1.1 -- Tamaño ajustado
    scaleObject('part' .. f, fixedSize, fixedSize)

    setObjectCamera('part' .. f, 'game') 
    addLuaSprite('part' .. f, true)
    
    local particleColor = math.random(1, 5) 
    if particleColor == 1 then
        setProperty('part' .. f .. '.color', getColorFromHex('FFC300')) -- Naranja
    elseif particleColor == 2 then
        setProperty('part' .. f .. '.color', getColorFromHex('7E7DA4')) -- Azul
        elseif particleColor == 3 then
        setProperty('part' .. f .. '.color', getColorFromHex('FFE2B3')) -- Marrón oscuro
        elseif particleColor == 4 then
        setProperty('part' .. f .. '.color', getColorFromHex('FFC300')) -- Naranja
    elseif particleColor == 5 then
        setProperty('part' .. f .. '.color', getColorFromHex('7E7DA4')) -- Azul
    end

    local fallTime = math.random(20, 25) -- Caída lenta
    local moveX = math.random(-400, 400) -- Movimiento lateral sutil
    local fadeY = math.random(2300, 2500) -- Ahora desaparecen más abajo

    doTweenY('fall' .. f, 'part' .. f, fadeY, fallTime, 'linear')
    doTweenX('side' .. f, 'part' .. f, posX + moveX, fallTime - 8, 'linear')
    doTweenAlpha('fade' .. f, 'part' .. f, 0, fallTime - 3, 'linear')
    doTweenAngle('angle'.. f, 'part' .. f, -180, fallTime - 12, 'linear')
    

    if f >= 100 then -- Permitimos más partículas activas
        f = 1
    end
end
