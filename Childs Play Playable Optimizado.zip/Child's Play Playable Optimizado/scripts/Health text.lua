--BUDYN--

function onCreatePost()
    makeLuaText('healthText', 'Health: ' .. math.floor(getProperty("health") * 50), 870, screenWidth / 2 - 550 / 2, screenHeight / 2 - 430 / 1.5)
    addLuaText('healthText')
    setTextSize('healthText', 30);
    setProperty('healthText.alpha', 0)
    setProperty('healthText.color', getIconColor('boyfriend'))
    if getPropertyFromClass('ClientPrefs', 'downScroll') == false then
        setProperty('healthText.y', 600)
        else
        setProperty('healthText.y', 55)
    end 
end

function setHudColor(col)
	if col == 'boyfriend' then
	setProperty('healthText.color', getIconColor('boyfriend'))
	end
	end

function onUpdate(elapsed)
	-- start of "update", some variables weren't updated yet
    setTextString('healthText', '' .. math.floor(getProperty("health") * 50))
    setProperty('healthText.color', getIconColor('boyfriend'))
end

function getIconColor(chr)
	return getColorFromHex(rgbToHex(getProperty(chr .. ".healthColorArray")))
end

function rgbToHex(array)
	return string.format('%.2x%.2x%.2x', array[1], array[2], array[3])
end

function mathlerp(from,to,i)
	return from+(to-from)*i
end

function round(x, n)
	n = math.pow(10, n or 0)
	x = x * n
	if x >= 0 then x = math.floor(x + 0.5) else x = math.ceil(x - 0.5) end
	return x / n
end


