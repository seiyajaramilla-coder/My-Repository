function onCreatePost()
end

function onStepHit()
initLuaShader("distort")
--Opponent team
--Bf team
if getProperty('health') >= 1.6 and getProperty('dad.curCharacter') == 'gumball' then
setSpriteShader("iconP2", "distort")
setShaderFloat('iconP2', 'binaryIntensity', getRandomFloat(4, 6))
elseif getProperty('health') < 1.6 and getProperty('dad.curCharacter') == 'gumball' then
setSpriteShader("iconP2", "distort")
setShaderFloat('iconP2', 'binaryIntensity', 0)
elseif getProperty('health') >= 1.6 and getProperty('dad.curCharacter') == 'gumballv3' or getProperty('dad.curCharacter') == 'gumbt' then
setSpriteShader("iconP2", "distort")
setShaderFloat('iconP2', 'binaryIntensity', 0)
end


if getProperty('health') >= 0.4 and getProperty('boyfriend.curCharacter') == 'cleannewbf_teaser_gun' then
setSpriteShader("iconP1", "distort")
setShaderFloat('iconP1', 'binaryIntensity', 0) 
elseif getProperty('health') < 0.4 and getProperty('boyfriend.curCharacter') == 'pre-surviver' then
setSpriteShader("iconP1", "distort")
setShaderFloat('iconP1', 'binaryIntensity', 0) 
elseif getProperty('health') < 0.4 and getProperty('boyfriend.curCharacter') == 'cleannewbf_teaser_gun' then
setSpriteShader("iconP1", "distort")
setShaderFloat('iconP1', 'binaryIntensity', getRandomFloat(4, 6))
end
end

function onUpdate()
    setShaderFloat('iconP1', 'negativity', 0.0)
    setShaderFloat('iconP2', 'negativity', 0.0)
end

function onUpdatePost()
    setShaderFloat('iconP1', 'negativity', 0.0)
    setShaderFloat('iconP2', 'negativity', 0.0)
end