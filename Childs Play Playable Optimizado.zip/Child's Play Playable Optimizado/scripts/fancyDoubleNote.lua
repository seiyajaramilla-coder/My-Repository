-- Script by Unbekannt, credit would be hella sick

-- - - - - - - - - - - - - - - - - - - - Edit these and adjust them for your song! - - - - - - - - - - - - - - - - - - - - - - - - 
-- ________ Animation Names: __________________________ 
-- Put in the names of the animations in the characters xml file
XML_l = 'left0' 		-- Left Sing
XML_d = 'down0' 		-- Down Sing
XML_u = 'up0' 			-- Up Sing
XML_r = 'right0' 		-- Right Sing

-- ________ Animation Offsets: ________________________ 
-- Put in the offset of all the animations here. First number is X, second is Y 
-- You can find the animation offset in the character editor
lOs = {'364', '316'}		-- Left Sing
dOs = {'269', '161'}	-- Down Sing
uOs = {'256', '218'}		-- Up Sing
rOs = {'262', '248'}		-- Right Sing	


		-- Template version
-- lOs = {'0', '0'}		-- Left Sing
-- dOs = {'0', '0'}		-- Down Sing
-- uOs = {'0', '0'}		-- Up Sing
-- rOs = {'0', '0'}		-- Right Sing	

-- ________ Base Offsets: ________________________ 
-- Position offset of the ghost 
offX = -27		-- X Positon Offset
offY = -205		-- Y Position Offset

-- ________ Name of the Ghost note: ___________________ 
-- The note type that uses the ghost, 'No Animation' is recommended (Since it doesn't make Dad sing)

-- ________ Distance of the ghost: ____________________ 
-- distance of the ghost 
ghostMove = 1200 -- ~300 is recommended

-- ________ Opacity of the ghost: _____________________
ghostAlpha = 0.7 -- 0.7 is recommended

-- ________ Time the ghost stays: _____________________
ghostDelay = 0.8 -- 0.3 is recommended



-- - - - - - - - - - - - - - - - - - - - The actuall code - - - - - - - - - - - - - - - - - - - - - - - - 
function onCreatePost()
	makeAnimatedLuaSprite('ghostDad', "characters/gumbtnew", getProperty('dad.x') + offX, getProperty('dad.y')- offY)
	addAnimationByPrefix('ghostDad', '0', XML_l, 24, false)
	addAnimationByPrefix('ghostDad', '1', XML_d, 24, false)
	addAnimationByPrefix('ghostDad', '2', XML_u, 24, false)
	addAnimationByPrefix('ghostDad', '3', XML_r, 24, false)
	setProperty('ghostDad.alpha', 0)
	setProperty('ghostDad.color', getColorFromHex('707090'))
	scaleObject('ghostDad',2.3,2.3)
	addLuaSprite('ghostDad', true)
end
local ghost = false 

function onStepHit()
if (curStep == 1535) then
ghost = true
end
if (curStep == 1537) then
ghost = false
end
if (curStep == 1567) then
ghost = true
end
if (curStep == 1569) then
ghost = false
end
if (curStep == 1599) then
ghost = true
end
if (curStep == 1601) then
ghost = false
end
end

function opponentNoteHit(id, noteData, noteType, isSustainNote)
if noteData == 2 then
			setProperty('ghostDad.offset.x', uOs[1])
			setProperty('ghostDad.offset.y', uOs[2])
			objectPlayAnimation('ghostDad', noteData, true)
			end
    if noteType == '' and ghost == true then
    setProperty('ghostDad.alpha', ghostAlpha)
    setProperty('ghostDad.x', getProperty('dad.x') + offX)
		cancelTween('doubleNoteTweenBack')
		cancelTween('doubleNoteTweenBackAlpha')
		runTimer('ghostSings', ghostDelay)

        doTweenX('doubleNoteTween', 'ghostDad', getProperty('dad.x') + offX + ghostMove, 0.8, 'sineOut' )
doTweenAlpha('doubleNoteTweenBackAlpha', 'ghostDad', 0, 0.5, 'quartIn')  
		objectPlayAnimation('ghostDad', noteData, true)
		if noteData == 0 then
			setProperty('ghostDad.offset.x', lOs[1])
			setProperty('ghostDad.offset.y', lOs[2])
		elseif noteData == 1 then
			setProperty('ghostDad.offset.x', dOs[1])
			setProperty('ghostDad.offset.y', dOs[2])
		elseif noteData == 2 then
			setProperty('ghostDad.offset.x', uOs[1])
			setProperty('ghostDad.offset.y', uOs[2])
		elseif noteData == 3 then
			setProperty('ghostDad.offset.x', rOs[1])
			setProperty('ghostDad.offset.y', rOs[2])
		end
	end
end