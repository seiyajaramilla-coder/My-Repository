-- use setGlobalFromScript('scripts/cammoving', variable, value) to change these thingsssig
offset = 15
speed = 2
local targ = {x = nil, y = nil}
local function lerp(start, goal, alpha) return (start + ((goal - start) * alpha)) end
local function boing(a,b,c) return math.max(b, math.min(c,a)) end
function onCreatePost() runHaxeCode('game.setOnLuas("mustHitSection", '..tostring(getPropertyFromClass('PlayState', 'SONG.notes')[1]['mustHitSection'])..')') end -- lmao
function opponentNoteHit(id, direction, balls)
	if not getPropertyFromGroup('notes', id, 'noAnimation') then
		if gfSection then
			if getPropertyFromGroup('notes', id, 'gfNote') then
				targ.x = direction == 0 and -offset or direction == 3 and offset or 0
				targ.y = direction == 2 and -offset or direction == 1 and offset or 0
			end
		elseif not mustHitSection then
			targ.x = direction == 0 and -offset or direction == 3 and offset or 0
			targ.y = direction == 2 and -offset or direction == 1 and offset or 0
		end
	end
end
function goodNoteHit(id, direction, balls)
	if not getPropertyFromGroup('notes', id, 'noAnimation') then
		if gfSection then
			if getPropertyFromGroup('notes', id, 'gfNote') then
				targ.x = direction == 0 and -offset or direction == 3 and offset or 0
				targ.y = direction == 2 and -offset or direction == 1 and offset or 0
			end
		elseif mustHitSection then
			targ.x = direction == 0 and -offset or direction == 3 and offset or 0
			targ.y = direction == 2 and -offset or direction == 1 and offset or 0
		end
	end
end
function onUpdate(e)
	if getProperty(gfSection and 'gf' or (mustHitSection and 'boyfriend' or 'dad') .. '.animation.curAnim.name') == 'idle' then
		targ.x = 0
		targ.y = 0
	end
	local thingie = boing(e*2.4*1*speed*playbackRate,0,1)
	if targ.x ~= nil then setProperty('camGame.targetOffset.x', lerp(getProperty('camGame.targetOffset.x'), targ.x, thingie)) end
	if targ.y ~= nil then setProperty('camGame.targetOffset.y', lerp(getProperty('camGame.targetOffset.y'), targ.y, thingie)) end
end