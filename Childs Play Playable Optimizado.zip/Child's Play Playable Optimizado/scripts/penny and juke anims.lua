-- SHADERS GRAH!!!!!! - jason 
--local pixel;

function onCreate()
		makeAnimatedLuaSprite("pennyNjuke", "school/Penny-and-juke", 610, 288)
		local pennyjukefps = 12;
		addAnimationByPrefix("pennyNjuke", "idle", "idle_0", pennyjukefps)
		addAnimationByPrefix("pennyNjuke", "idle-bf", "lookbf_0", pennyjukefps)
		addAnimationByPrefix("pennyNjuke", "idle-gumball", "lookgumball_0", pennyjukefps)
		addAnimationByPrefix("pennyNjuke", "transition", "anim_0", pennyjukefps, false)
		addAnimationByPrefix("pennyNjuke", "transitionBF", "blink_0", pennyjukefps, false)
		addAnimationByPrefix("pennyNjuke", "transitionDAD", "blink_0", pennyjukefps, false)
		addOffset("pennyNjuke", "idle-gumball",-240,-184)
		addOffset("pennyNjuke", "transitionDAD",-240,-184)
		scaleObject("pennyNjuke",1.96,1.96, true)
		playAnim("pennyNjuke", "idle")
		
		makeAnimatedLuaSprite("pennyNjuker", "school/Penny-and-juke", 610, 288)
		addAnimationByPrefix("pennyNjuker", "idle", "idle_0", pennyjukefps)
		addAnimationByPrefix("pennyNjuker", "idle-bf", "lookbf_0", pennyjukefps)
		addAnimationByPrefix("pennyNjuker", "idle-gumball", "lookgumball_0", pennyjukefps)
		addAnimationByPrefix("pennyNjuker", "transition", "anim_0", pennyjukefps, false)
		addAnimationByPrefix("pennyNjuker", "transitionBF", "blink_0", pennyjukefps, false)
		addAnimationByPrefix("pennyNjuker", "transitionDAD", "blink_0", pennyjukefps, false)
		addOffset("pennyNjuker", "idle-gumball",-240,-110)
		addOffset("pennyNjuker", "transitionDAD",-240,-110)
		scaleObject("pennyNjuker",1.96,1.96, true)
		playAnim("pennyNjuker", "idle")
		
		setProperty('pennyNjuker.x', getProperty('pennyNjuke.x') + 0)--X--
setProperty('pennyNjuker.y', getProperty('pennyNjuke.y') + 540)--Y--
setProperty('pennyNjuker.alpha', 0.35)
setProperty('pennyNjuker.angle', 180)
setProperty('pennyNjuker.flipX', true)
setObjectOrder('pennyNjuker', getObjectOrder('pennyNjuke'))
		
end

local canPlayOtherAnims = true;
function onTimerCompleted(tag, loops, loopsLeft)
	if tag == "pennyAnim" then
		canPlayOtherAnims = true;
		if getProperty("pennyNjuke.animation.curAnim.name") == "transitionDAD" then
        playAnim("pennyNjuke", "idle-gumball") 
        end
		if getProperty("pennyNjuke.animation.curAnim.name") == "transitionBF" then
         playAnim("pennyNjuke", "idle-bf") 
         end
         if getProperty("pennyNjuker.animation.curAnim.name") == "transitionDAD" then
        playAnim("pennyNjuker", "idle-gumball") 
        end
		if getProperty("pennyNjuker.animation.curAnim.name") == "transitionBF" then
         playAnim("pennyNjuker", "idle-bf") 
         end
	end
end

local pennyAnimReal = false;
local switchTimer = 0.2;
function onMoveCamera(focus)
	if not pennyAnimReal or not canPlayOtherAnims then
      return; 
       end
	if getProperty("pennyNjuke.animation.curAnim.name") == "idle-gumball" and focus ~= "dad" then
		playAnim("pennyNjuke", "transitionBF")
		canPlayOtherAnims = false;
		runTimer("pennyAnim", switchTimer)
	end
	if getProperty("pennyNjuke.animation.curAnim.name") == "idle-bf" and focus == "dad" then
		playAnim("pennyNjuke", "transitionDAD")
		canPlayOtherAnims = false;
		runTimer("pennyAnim", switchTimer)
	end
	if getProperty("pennyNjuker.animation.curAnim.name") == "idle-gumball" and focus ~= "dad" then
		playAnim("pennyNjuker", "transitionBF")
		canPlayOtherAnims = false;
		runTimer("pennyAnim", switchTimer)
	end
	if getProperty("pennyNjuker.animation.curAnim.name") == "idle-bf" and focus == "dad" then
		playAnim("pennyNjuker", "transitionDAD")
		canPlayOtherAnims = false;
		runTimer("pennyAnim", switchTimer)
	end
end


function onStepHit()
	if curStep == 500 then
        playAnim("pennyNjuke", "transition")
        playAnim("pennyNjuker", "transition")
    end    
    if curStep == 515 then --change this to when they are happy!!
        playAnim("pennyNjuke", "transitionDAD")
        playAnim("pennyNjuker", "transitionDAD")
        runTimer("pennyAnim", switchTimer)
        pennyAnimReal = true;
    end
	if curStep == 1276 then --change this to when they are pibbyfied
		pennyAnimReal = false;
	end
end

--thanks for da code
function onBeatHit()
	if mustHitSection then
    onMoveCamera("bf")
    else 
    onMoveCamera("dad") 
    end
end