function goodNoteHit(index, noteDir, noteType, isSustainNote)
			setProperty("boyfriend.specialAnim", true)
end
function opponentNoteHit(index, noteDir, noteType, isSustainNote)
		setProperty("dad.specialAnim", true)
end