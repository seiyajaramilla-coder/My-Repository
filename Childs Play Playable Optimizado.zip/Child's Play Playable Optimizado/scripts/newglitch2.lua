local shaderName = "NewGlitch2"
randomxd = math.random(10,20)

function onCreatePost()
initLuaShader("distort")
end

function onStepHit()

	randomxd = math.random(2,5)/math.random(1,3)
	
	if curStep == 1656 then
		shaderCoordFix() -- initialize a fix for textureCoord when resizing game window

setProperty("dad.color", getColorFromHex("2100FF"))

		makeLuaSprite("NewGlitch2")
		makeGraphic("NewGlitch2", screenWidth, screenHeight)

		setSpriteShader("shaderImage", "NewGlitch2")


		runHaxeCode([[
			var shaderName = "]] .. shaderName .. [[";
			
			game.initLuaShader(shaderName);
            var shader1 = game.createRuntimeShader('bloom1');
			
			var shader0 = game.createRuntimeShader(shaderName);
			game.camGame.setFilters([new ShaderFilter(shader1),new ShaderFilter(shader0),new ShaderFilter(game.getLuaObject("bloom").shader)]);
			game.camHUD.setFilters([]);
			game.getLuaObject("NewGlitch2").shader = shader0; // setting it into temporary sprite so luas can set its shader uniforms/properties
            game.getLuaObject("bloom1").shader = shader1; // setting it into temporary sprite so luas can set its shader uniforms/properties
			return;
		]])
		
	end
	if curStep == 1657 then
	initLuaShader("negative")
setShaderFloat("dad", "negativity", 1) 
setSpriteShader("dad", "negative")
end
	
	if curStep == 1659 then
	removeSpriteShader('dad')
	setProperty('dad.color', getColorFromHex('707090'))
		setShaderFloat('NewGlitch2', 'negativity', 1)
	end

	if curStep == 1664 then
		removeSpriteShader('NewGlitch2')
		makeLuaSprite('blur')
    setSpriteShader('blur', 'gaussian_blur')
    initLuaShader("gaussian_blur")
setSpriteShader('wake up', 'gaussian_blur');
		runHaxeCode([[
			trace(ShaderFilter);
			var chromToggle = game.createRuntimeShader('ChromaticAbberationHUD');
            var shaderVcr = game.createRuntimeShader('glitchChromatic');
            var shaderblur = game.createRuntimeShader('gaussian_blur');
            var shader1 = game.createRuntimeShader('bloom1');
            
			game.camGame.setFilters([new ShaderFilter(shaderVcr),new ShaderFilter(chromToggle),new ShaderFilter(shader1),new ShaderFilter(shaderblur),new ShaderFilter(game.getLuaObject("bloom").shader)]);
			game.camHUD.setFilters([new ShaderFilter(shaderVcr),new ShaderFilter(chromToggle),new ShaderFilter(shaderblur)]);
			game.getLuaObject('chromToggle').shader = chromToggle;
            game.getLuaObject("temporaryShader1").shader = shaderVcr;
            game.getLuaObject("blur").shader = shaderblur; // setting it into temporary sprite so luas can set its shader uniforms/properties
            game.getLuaObject("bloom1").shader = shader1; // setting it into temporary sprite so luas can set its shader uniforms/properties
			return;
		]])
		setProperty('Opo-G.alpha', 0)
		setProperty('Opo-R.alpha', 0)
		setProperty('Opo-line.alpha', 0)
		setProperty('healthBarScript.alpha', 1)
	setProperty('glitch1.alpha', 1)
			setProperty('theGlitch2.alpha', 1)
		setProperty("boyfriend.color", getColorFromHex("707090"))
		setProperty("dad.color", getColorFromHex("707090"))
		
		setProperty('camGame.y', 0)
	end
	
	if curStep == 1824 then
	initLuaShader("gaussian_blur")
setSpriteShader('cn', 'gaussian_blur');
end

if curStep == 1918 then
makeLuaSprite('blur')
    setSpriteShader('blur', 'gaussian_blur')
    initLuaShader("gaussian_blur")
setSpriteShader('cn', 'gaussian_blur');
runHaxeCode([[
			trace(ShaderFilter);
            var shaderVcr = game.createRuntimeShader('glitchChromatic');
			
			game.camOther.setFilters([new ShaderFilter(shaderVcr)]);
            game.getLuaObject("temporaryShader1").shader = shaderVcr;
			return;
		]])
	end
	if curStep == 1956 then
	removeSpriteShader('cn')
	removeSpriteShader('cinematicBorderBloom1')
	removeSpriteShader('cinematicBorderBloom2')
	removeLuaSprite('cinematicBorderBloom1',true)
	removeLuaSprite('cinematicBorderBloom2',true)
	removeLuaScript('custom_events/Bars Bloom.lua')
	removeSpriteShader('cinematicBorderBloom1')
	removeSpriteShader('cinematicBorderBloom2')
	removeLuaSprite('cinematicBorderBloom1',true)
	removeLuaSprite('cinematicBorderBloom2',true)
	removeLuaScript('custom_events/Bars Bloom.lua') 
	setProperty("boyfriend.color", getColorFromHex("707090"))
	setProperty("dad.color", getColorFromHex("707090"))
		runHaxeCode([[
			trace(ShaderFilter);
			var chromToggle = game.createRuntimeShader('ChromaticAbberationHUD');
            var shaderVcr = game.createRuntimeShader('glitchChromatic');
            var shader1 = game.createRuntimeShader('bloom1');
            
			game.camGame.setFilters([new ShaderFilter(shaderVcr),new ShaderFilter(chromToggle),new ShaderFilter(shader1),new ShaderFilter(game.getLuaObject("bloom").shader)]);
			game.camHUD.setFilters([new ShaderFilter(shaderVcr),new ShaderFilter(chromToggle)]);
			game.camOther.setFilters([]);
			game.getLuaObject('chromToggle').shader = chromToggle;
            game.getLuaObject("temporaryShader1").shader = shaderVcr;
            game.getLuaObject("bloom1").shader = shader1; // setting it into temporary sprite so luas can set its shader uniforms/properties
            
            FlxG.cameras.remove(overlayCam2,false);
			return;
		]])
		end
	
	setShaderFloat("NewGlitch2", "binaryIntensity", randomxd-2)
	
end

function onUpdate(elapsed)
    setShaderFloat("shaderImage", "iTime", os.clock())
    setShaderFloat("blur", "iTime", os.clock())
    setShaderFloat("blur", "distort", 10)
    setShaderFloat("cn", "iTime", os.clock())
    setShaderFloat("cn", "distort", 10)
    setShaderFloat("wake up", "iTime", os.clock())
    setShaderFloat("wake up", "distort", 10)
    setShaderFloat("cinematicBorder1", "iTime", os.clock())
    setShaderFloat("cinematicBorder1", "distort", 10)
    setShaderFloat("cinematicBorder2", "iTime", os.clock())
    setShaderFloat("cinematicBorder2", "distort", 10)
end

function shaderCoordFix()
    runHaxeCode([[
        resetCamCache = function(?spr) {
            if (spr == null || spr.filters == null) return;
            spr.__cacheBitmap = null;
            spr.__cacheBitmapData = null;
        }
        
        fixShaderCoordFix = function(?_) {
            resetCamCache(game.camGame.flashSprite);
            resetCamCache(game.camHUD.flashSprite);
            resetCamCache(game.camOther.flashSprite);
        }
    
        FlxG.signals.gameResized.add(fixShaderCoordFix);
        fixShaderCoordFix();
        return;
    ]])
    
    local temp = onDestroy
    function onDestroy()
        runHaxeCode([[
            FlxG.signals.gameResized.remove(fixShaderCoordFix);
            return;
        ]])
        if (temp) then temp() end
    end
end