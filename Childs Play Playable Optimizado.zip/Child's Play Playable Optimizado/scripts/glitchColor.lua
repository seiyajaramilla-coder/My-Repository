local shaderName = 'distort'
function onCreatePost()
initLuaShader(shaderName)
makeLuaSprite('doritos2')
makeGraphic('doritos2', screenWidth, screenHeight)
runHaxeCode([[
var shader1 = game.createRuntimeShader(']]..shaderName..[[');
game.getLuaObject('doritos2').shader = shader1;
shader1.setFloat("negativity", 0.0);
shader1.setFloat("binaryIntensity", 1000.0);
]])
end

local dadGlitchIntensity = 0;
function onUpdatePost(elapsed)
setShaderFloat('doritos2',"binaryIntensity", dadGlitchIntensity);
end

function opponentNoteHit(id, direction ,noteType, isSustainNote)
	if _G['dadGhostData.strumTime'] == getPropertyFromGroup('notes', id, 'strumTime') and not isSustainNote and getProperty('dad.curCharacter') == 'gumball' then
runHaxeCode([[
game.camGame.shake(FlxG.random.float(0.015, 0.02), FlxG.random.float(0.075, 0.125));
game.camHUD.shake(FlxG.random.float(0.015, 0.02), FlxG.random.float(0.075, 0.125));
]])
        setPropertyFromGroup('opponentStrums', 0, 'x', defaultOpponentStrumX0 + getRandomInt(-8, 8))
        setPropertyFromGroup('opponentStrums', 1, 'x', defaultOpponentStrumX1 + getRandomInt(-8, 8))
        setPropertyFromGroup('opponentStrums', 2, 'x', defaultOpponentStrumX2 + getRandomInt(-8, 8))
        setPropertyFromGroup('opponentStrums', 3, 'x', defaultOpponentStrumX3 + getRandomInt(-8, 8))
        setPropertyFromGroup('opponentStrums', 0, 'y', defaultOpponentStrumY0 + getRandomInt(-8, 8))
        setPropertyFromGroup('opponentStrums', 1, 'y', defaultOpponentStrumY1 + getRandomInt(-8, 8))
        setPropertyFromGroup('opponentStrums', 2, 'y', defaultOpponentStrumY2 + getRandomInt(-8, 8))
        setPropertyFromGroup('opponentStrums', 3, 'y', defaultOpponentStrumY3 + getRandomInt(-8, 8))
	end
	if getProperty('dad.curCharacter') == 'gumball' then
setShaderFloat('doritos2',"negativity", 1);
dadGlitchIntensity = getRandomFloat(-1, -0.5);
end
if not isSustainNote and getProperty('dad.curCharacter') == 'gumball' then
	if _G['dadGhostData.strumTime'] == getPropertyFromGroup('notes', id, 'strumTime') then
	setProperty("dad.color", getColorFromHex("2100FF"))
	setSpriteShader("dadPhantom", "distort")
setShaderFloat("dadPhantom", "binaryIntensity", getRandomFloat(-1, -0.5))
setShaderFloat("dadPhantom", "negativity", 1) 
	runTimer('removeshader',0.1)
runHaxeCode([[
game.dad.shader = game.getLuaObject('doritos2').shader;
]])
else
removeSpriteShader('dadPhantom') 
setProperty("dad.color", getColorFromHex("707090"))
runHaxeCode([[
game.dad.shader = null;
]])
	end
end
	if not isSustainNote and getProperty('dad.curCharacter') == 'gumball' then
		_G['dadGhostData.strumTime'] = getPropertyFromGroup('notes', id, 'strumTime')	
	end
	if not isSustainNote and getProperty('dad.curCharacter') == 'gumball' then
	if getRandomBool(50) then
	glitchShaderIntensity = getRandomFloat(0.2, 0.7);
	end
	end
end

function onTimerCompleted(t)
if t == 'removeshader' then
removeSpriteShader('dadPhantom')
setProperty("dad.color", getColorFromHex("707090"))
runHaxeCode([[
game.dad.shader = null;
]])
end
end
