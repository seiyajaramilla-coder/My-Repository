chromatic = 0
el = 0
glitchShaderIntensity = 0
function onCreatePost()
    initLuaShader("glitchChromatic")

    makeLuaSprite("temporaryShader1")
    setSpriteShader("temporaryShader1", "glitchChromatic") 
    makeLuaSprite('shaderXb',nil,0,0)
   
   runHaxeCode([[
			trace(ShaderFilter);

			game.camGame.setFilters([new ShaderFilter(game.getLuaObject("temporaryShader1").shader),new ShaderFilter(game.getLuaObject("temporaryShader1").shader)]);
		]])
		
end

--[[function onEvent(name,value1,value2)
    if name == '' then
        if value1 == 'ChangeGlitchIntensity' then
            chromatic = tonumber(value2)
        end
    end
end]]

function opponentNoteHit(id,noteData,noteType,isSusNote)
    if noteType =='GF Sing But Not Visible Note' or noteType =='GF Sing' then
        notGF = false
    else
        notGF = true
    end

    if notGF and math.random(1,2) == 1 and noteType ~= ('Glitch Note' and 'Second Char Glitch') then
        chromatic = 0
        glitchShaderIntensity = getRandomFloat(0.1 + chromatic, 0.4 + chromatic)
    elseif noteType == ('Glitch Note' or 'Second Char Glitch') then
        chromatic = 0.2
        glitchShaderIntensity = getRandomFloat(0.2 + chromatic, 0.8 + chromatic)
        elseif curBeat > 760 then
        chromatic = 2.2
        glitchShaderIntensity = getRandomFloat(0.2 + chromatic, 0.8 + chromatic)
    end
end

function onUpdate(elapsed)
    el = el + elapsed
    setShaderFloat('temporaryShader1', "uTime", el)

    glitchShaderIntensity = math.lerp(glitchShaderIntensity, 0, boundTo(elapsed * 7, 0, 1));

    local  Value1 = getProperty('shaderXb.x')
    setShaderFloat('temporaryShader1', "glitchMultiply", glitchShaderIntensity)
end

function boundTo(value,min,max)
    return math.max(min,math.min(max,value))
end

function math.lerp(from,to,i)
    return from+(to-from)*i
end

