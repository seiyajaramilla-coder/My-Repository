--CODIGO BY SEBAS_AGUA
function MHI(tag, ptha, x, y, Sx, Sy)
    makeLuaSprite(tag, ptha, x, y)
	setObjectCamera(tag, 'camHud')
	scaleObject(tag, Sx, Sy)
end
 
function onCreatePost()
makeLuaSprite('rainbow', 'health bar/rainbow', 537, downscroll and -345 or 710)
scaleObject('rainbow', 0.4, 0.4)
setObjectCamera('rainbow', 'camHUD')
addLuaSprite('rainbow')
setProperty('rainbow.alpha', 1)

makeAnimatedLuaSprite('glitch1', 'health bar/glitch1', 600, downscroll and -38 or 520)
    addAnimationByPrefix('glitch1', 'idle', 'Symbole 1', 24, true)
    scaleObject('glitch1', 0.35, 0.35)
    addLuaSprite('glitch1', false);
    setObjectCamera('glitch1', 'camHUD')
    setProperty('glitch1.alpha', 0)
    
    makeAnimatedLuaSprite('theGlitch2', 'health bar/theGlitch', 550, downscroll and -53 or 495)
    addAnimationByPrefix('theGlitch2', 'idle', 'theGlitch glitching', 12, true)
    scaleObject('theGlitch2', 0.2, 0.2)
    addLuaSprite('theGlitch2', false);
    setObjectCamera('theGlitch2', 'camHUD')
    setProperty('theGlitch2.alpha', 0)

makeLuaSprite('rapper', 'health bar/theRapper', 597, downscroll and -367 or 732)
scaleObject('rapper', 0.1, 0.1)
setObjectCamera('rapper', 'camHUD')
addLuaSprite('rapper', false)
setProperty('rapper.alpha', 1)

MHI('Opo-G', 'health bar/healthbar', 380, downscroll and -300 or 665, 0.25, 0.25)
    addLuaSprite('Opo-G', false)

    MHI('Opo-R', 'health bar/healthbar', 380, downscroll and -300 or 665, 0.25, 0.25)
    addLuaSprite('Opo-R', false)

    MHI('Opo-line', 'health bar/healthbarBG', 380, downscroll and -300 or 665, 0.25, 0.25)
addLuaSprite('Opo-line', false)

makeLuaSprite('mic', 'health bar/mic-icon', 797, downscroll and 18 or 500)
scaleObject('mic', 0.5, 0.5)
setObjectCamera('mic', 'camHUD')
addLuaSprite('mic', false)
setProperty('mic.alpha', 0)
setObjectOrder('mic', getObjectOrder('iconP1')-1) 

makeLuaSprite('gun', 'health bar/gun-icon', 797, downscroll and 18 or 500)
scaleObject('gun', 0.9, 0.9)
setObjectCamera('gun', 'camHUD')
addLuaSprite('gun', false)
setProperty('gun.alpha', 0)
setObjectOrder('gun', getObjectOrder('iconP1')-1)
end

function onUpdatePost(elapsed)
setProperty('mic.x', getProperty('iconP1Pos.x')-40)
setProperty('mic.y', getProperty('iconP1.y')+50)
setProperty('gun.x', getProperty('iconP1Pos.x')-85)
setProperty('gun.y', getProperty('iconP1.y')+0)
setProperty('Opo-G.color', getColorFromHex(rgbToHex(getProperty('boyfriend.healthColorArray'))))  
setProperty('Opo-R.color', getColorFromHex(rgbToHex(getProperty('dad.healthColorArray'))))

    curHealth = (getProperty('health')/2)
	setProperty('Play-R._frame.frame.width', (math.lerp(2048, 0, 0-curHealth)));
    setProperty('Opo-R._frame.frame.width', 100 + (math.lerp(2048, 0, curHealth)));

    h = round(getProperty('healthBar.percent'), 0)

end

function fixTimer(millisecond)
    local seconds = math.floor(millisecond / 1000)
    return string.format('%01d:%02d', (seconds / 60) % 60, seconds % 60)  
end

function round(x, n)
    n = math.pow(10, n or 0)
    x = x * n
    if x >= 0 then x = math.floor(x + 0.5) else x = math.ceil(x - 0.5) end
    return x / n
end

function math.lerp(a, b, t)
	return a + t * (b - a);
end

function rgbToHex(array)
	return string.format('%.2x%.2x%.2x', array[1], array[2], array[3])
end
