function onCreate()
    makeLuaSprite('cn', 'cnlogo', 1120, 590)
    scaleObject('cn', 0.45, 0.45)
    addLuaSprite('cn', true)
setObjectCamera('cn', 'other')
setProperty('cn.alpha', 0.5)
end

function onUpdatePost(elapsed)
if downscroll then
    setProperty('cn.y', 60)
end
end