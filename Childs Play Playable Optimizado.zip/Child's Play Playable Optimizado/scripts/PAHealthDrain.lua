
function opponentNoteHit(id,dir,type,sus)
if curStep > 1407 then
if getProperty('health') > 0.2 and getProperty('dad.curCharacter') == 'gumbt' then
setProperty('health',getProperty('health') - 0.0075)
end
end

if getProperty('health') > 0.2 and songName == "Child's Play" and type ~= 'GF Sing' and type ~= 'GF Sing But Not Visible Note' then
 setProperty('health',getProperty('health')- 0.006) 
end

if getProperty('dad.curCharacter') == 'gumbt' and type =='Miss Note' then
setProperty('health',getProperty('health') - 0.005)
end
if getProperty('health') > 0.2 and getProperty('dad.curCharacter') == 'gumball' then
setProperty('health',getProperty('health') - 0.015)
end
if getProperty('dad.curCharacter') == 'gumballv3' and type =='Miss Note' then
setProperty('health',getProperty('health') - 0.005)
end
end