bordersSize = 360

function onUpdate(elapsed)
    setShaderFloat("blur", "iTime", os.clock())
    setShaderFloat("blur", "distort", 10)
    end
    

function onCreate()

end
    
function onEvent(name,value1,value2)
    if name == 'Bars Bloom' then
    makeLuaSprite('blur')
    setSpriteShader('blur', 'gaussian_blur')
    initLuaShader("gaussian_blur")

runHaxeCode([[
        FlxG.cameras.remove(game.camHUD,false);
       		FlxG.cameras.remove(game.camOther,false);
       		var overlayCam2:FlxCamera = new FlxCamera();
        overlayCam2.bgColor = 0x00;
       		setVar('overlayCam2', overlayCam2);
        FlxG.cameras.add(overlayCam2,false);
       		FlxG.cameras.add(game.camHUD,false);
        FlxG.cameras.add(game.camOther,false);
        
        var shaderblur = game.createRuntimeShader('gaussian_blur');
        getVar("overlayCam2").setFilters([new ShaderFilter(shaderblur)]);
        game.getLuaObject("blur").shader = shaderblur; // setting it into temporary sprite so luas can set its shader uniforms/properties
]])

    makeLuaSprite('cinematicBorderBloom1',nil,-100,0)
    makeLuaSprite('cinematicBorderBloom2',nil,-100,screenHeight - bordersSize)
    setSpriteShader('cinematicBorderBloom1', 'gaussian_blur');
setSpriteShader('cinematicBorderBloom2', 'gaussian_blur');
    for borders = 1,2 do
        makeGraphic('cinematicBorderBloom'..borders,screenWidth + 200,bordersSize,'000000')
        setObjectCamera('cinematicBorderBloom'..borders,'camHUD')
        addLuaSprite('cinematicBorderBloom'..borders,false) 
    end

    runHaxeCode([[
                  game.getLuaObject("cinematicBorderBloom1").camera = getVar("overlayCam2");
                  game.getLuaObject("cinematicBorderBloom2").camera = getVar("overlayCam2");
                  game.getLuaObject("cutscene").camera = getVar("overlayCam2");
    ]])
    
    setProperty('cinematicBorderBloom1.y',-bordersSize)
    setProperty('cinematicBorderBloom2.y',screenHeight)
        doTweenY('cenematicB1Y','cinematicBorderBloom1',-bordersSize + value1, value2, 'quadOut')
        doTweenY('cenematicB2Y','cinematicBorderBloom2',screenHeight - value1, value2, 'quadOut')
    end
end