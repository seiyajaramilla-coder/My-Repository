
function onEvent(n,v1,v2)
	if n == 'Flash Other' then
	   makeLuaSprite('flash2o', 'luze', 0, 0);
        makeGraphic('flash2o',screenWidth,screenHeight,'ffffff')
	      addLuaSprite('flash2o', true);

	setObjectCamera ('flash2o', 'other')
	      setProperty('flash2o.scale.x',3)
	      setProperty('flash2o.scale.y',3)
		setProperty('flash2o.alpha',v2)
		doTweenAlpha('flTwo','flash2o',0,v1,'linear')
	end



end