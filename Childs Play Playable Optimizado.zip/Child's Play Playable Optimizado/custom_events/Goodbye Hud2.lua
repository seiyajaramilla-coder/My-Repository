function onEvent(name,value1,value2)
	if name == 'Goodbye Hud2' then
	setProperty('camHUD.alpha',tonumber(value1))
	end
end