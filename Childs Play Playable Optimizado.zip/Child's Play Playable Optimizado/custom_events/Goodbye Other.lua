function onEvent(name,value1,value2)
	if name == 'Goodbye Other' then
	setProperty('camHUD.alpha',0)
	setProperty('camGame.alpha',0)
	doTweenAlpha('otheralpha', 'camOther', tonumber(value1), tonumber(value2), 'linear');
	end
end