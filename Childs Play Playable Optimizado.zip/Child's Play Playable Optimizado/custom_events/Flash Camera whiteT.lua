--Code By [SebastianPr]
function onCreatePost()
if shadersEnabled then
makeLuaSprite('bloom');
setSpriteShader('bloom', 'bloomflash');
makeLuaSprite('bloomEffect', '', 0,0)
makeLuaSprite('bloomStrength', '', 1,0)
makeLuaSprite('bloomContrast', '', 1,0)
makeLuaSprite('bloomBrightness', '', 0,0)


addHaxeLibrary('ShaderFilter', 'openfl.filters')

end
end
local offset = 0.0018;

function onUpdate()
    setShaderFloat('bloom', 'gOffset', - offset);
    setShaderFloat('bloom', 'bOffset', 0);
    setShaderFloat('bloom', 'rOffset', offset);
   
    
    setShaderFloat("bloom", "effect", getProperty('bloomEffect.x'))
    setShaderFloat("bloom", "strength", getProperty('bloomStrength.x'))
    setShaderFloat("bloom", "contrast", getProperty('bloomContrast.x'))
    setShaderFloat("bloom", "brightness", getProperty('bloomBrightness.x'))
end

function onEvent(n,v1,v2)
	if n == 'Flash Camera whiteT' then
	setProperty('bloomEffect.x', v2 *2)
        setProperty('bloomStrength.x', v2 *2)
        doTweenX("bloomEffect", "bloomEffect", 0, v1, "linear")
        doTweenX("bloomStrength", "bloomStrength", 0, v1, "linear")
   end
   end