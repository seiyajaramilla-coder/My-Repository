
function onEvent(n,v1,v2)
	if n == 'Flash' then
	   makeLuaSprite('flash2', 'luze', 0, 0);
        makeGraphic('flash2',screenWidth,screenHeight,'ffffff')
	      addLuaSprite('flash2', true);

setBlendMode('flash2', 'add')
	setObjectCamera ('flash2', 'camGame')
	      setProperty('flash2.scale.x',3)
	      setProperty('flash2.scale.y',3)
		setProperty('flash2.alpha',v2)
		doTweenAlpha('flTw','flash2',0,v1,'linear')
	end



end