bordersSize = 360

function onCreate()
runHaxeCode([[
        FlxG.cameras.remove(game.camHUD,false);
       		FlxG.cameras.remove(game.camOther,false);
       		var overlayCam:FlxCamera = new FlxCamera();
        overlayCam.bgColor = 0x00;
       		setVar('overlayCam', overlayCam);
        FlxG.cameras.add(overlayCam,false);
       		FlxG.cameras.add(game.camHUD,false);
        FlxG.cameras.add(game.camOther,false);
]])

    makeLuaSprite('cinematicBorder1',nil,-100,0)
    makeLuaSprite('cinematicBorder2',nil,-100,screenHeight - bordersSize)
    for borders = 1,2 do
        makeGraphic('cinematicBorder'..borders,screenWidth + 200,bordersSize,'000000')
        setObjectCamera('cinematicBorder'..borders,'camHUD')
        addLuaSprite('cinematicBorder'..borders,false) 
    end

    runHaxeCode([[
                  game.getLuaObject("cinematicBorder1").camera = getVar("overlayCam");
                  game.getLuaObject("cinematicBorder2").camera = getVar("overlayCam");
                  game.getLuaObject("cutscene").camera = getVar("overlayCam");
    ]])
    
    setProperty('cinematicBorder1.y',-bordersSize)
    setProperty('cinematicBorder2.y',screenHeight)
end
    
function onEvent(name,value1,value2)
    if name == 'Bars' then
        doTweenY('cenematic1Y','cinematicBorder1',-bordersSize + value1, value2, 'quadOut')
        doTweenY('cenematic2Y','cinematicBorder2',screenHeight - value1, value2, 'quadOut')
    end
end