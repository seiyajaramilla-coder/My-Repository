local shaderName = "gaussian_blur" -- Asegúrate de que coincide con el nombre del archivo .frag
local shaderActive = false

function onCreate()
    -- Crea un sprite invisible para aplicar el shader
    makeLuaSprite('shaderHolder')
    setSpriteShader('shaderHolder', shaderName)
end

function onEvent(name, value1, value2)
    if name == 'Toggle Blur Shader' then
        if value1:lower() == 'on' then
            if not shaderActive then
                applyShader()
                shaderActive = true
            end
            if value2 ~= nil and value2 ~= '' then
                setShaderFloat('shaderHolder', 'distort', tonumber(value2))
            end
        elseif value1:lower() == 'off' then
            removeShader()
            shaderActive = false
        end
    end
end

function applyShader()
    runHaxeCode([[
        var shader = game.getLuaObject("shaderHolder").shader;
        game.camGame.setFilters([new ShaderFilter(shader)]);
        game.camHUD.setFilters([new ShaderFilter(shader)]);
        game.camOther.setFilters([new ShaderFilter(shader)]);
    ]])
end

function removeShader()
    runHaxeCode([[
        game.camGame.setFilters([]);
        game.camHUD.setFilters([]);
        game.camOther.setFilters([]);
    ]])
end